# ML2 数据降维模型课堂材料

打开 [降维模拟 Notebook](ML2-降维模拟.ipynb)，从第一个单元开始依次运行。手算例和模拟数据均由 Notebook 生成。使用 JupyterLab 或 VS Code，选择已安装 NumPy、pandas、Matplotlib 和 scikit-learn 的 Python 内核。

[五个交互实验](ML2-数据降维模型-交互演示.html) 可用浏览器离线打开。

| 实验 | 课件页码 |
| --- | --- |
| 01 二维投影与保留方差 | 19 |
| 02 十维 PCA 的累计方差 | 22 |
| 03 主成分个数与交叉验证 | 30 |
| 04 斜率加权前后的主成分方向 | 35 |
| 05 PCR 与 PLS 的测试曲线 | 42 |
