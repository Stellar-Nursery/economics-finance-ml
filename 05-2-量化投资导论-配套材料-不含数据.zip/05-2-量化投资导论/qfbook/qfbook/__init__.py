"""
qfbook — 《量化投资：理论、方法与实践》配套代码库
=====================================================

模块结构：
    qfbook.data     数据加载与预处理
    qfbook.factor   因子计算与检验
    qfbook.backtest 回测引擎
    qfbook.risk     风险模型
    qfbook.optim    组合优化
    qfbook.viz      可视化工具
    qfbook.utils    通用工具函数
"""

__version__ = "0.1.0"
