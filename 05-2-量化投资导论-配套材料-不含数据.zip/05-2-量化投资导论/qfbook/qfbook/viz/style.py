"""
qfbook.viz.style — 统一绘图风格
=================================
"""

import matplotlib as mpl
import matplotlib.pyplot as plt


def set_qfbook_style():
    """
    设置教材统一的绘图风格。

    特点：
    - 中文字体支持（SimHei / PingFang SC）
    - 学术论文风格的配色方案
    - 适合印刷的 DPI 和字号
    """
    # 中文字体
    import platform
    system = platform.system()
    if system == "Windows":
        font_family = "SimHei"
    elif system == "Darwin":  # macOS
        font_family = "PingFang SC"
    else:  # Linux
        font_family = "WenQuanYi Micro Hei"

    plt.rcParams.update({
        # 字体
        "font.sans-serif": [font_family, "DejaVu Sans"],
        "axes.unicode_minus": False,
        "font.size": 11,
        "axes.titlesize": 13,
        "axes.labelsize": 11,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
        "legend.fontsize": 10,

        # 图形
        "figure.figsize": (10, 5),
        "figure.dpi": 150,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",

        # 线条
        "lines.linewidth": 1.5,
        "axes.linewidth": 0.8,

        # 网格
        "axes.grid": True,
        "grid.alpha": 0.3,
        "grid.linewidth": 0.5,

        # 颜色
        "axes.prop_cycle": mpl.cycler(
            color=[
                "#2E86AB",  # 蓝
                "#E84855",  # 红
                "#44BBA4",  # 绿
                "#F5A623",  # 橙
                "#7B68EE",  # 紫
                "#20B2AA",  # 青
                "#FF6B6B",  # 浅红
                "#4ECDC4",  # 浅绿
            ]
        ),
    })
