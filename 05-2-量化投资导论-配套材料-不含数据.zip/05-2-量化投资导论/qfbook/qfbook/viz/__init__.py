"""
qfbook.viz — 可视化工具
========================

提供统一的绘图风格和常用可视化函数。
"""

from qfbook.viz.style import set_qfbook_style
from qfbook.viz.plots import (
    plot_market_cap_distribution,
    plot_industry_structure,
    plot_turnover_analysis,
    plot_cumulative_return,
    plot_drawdown,
    plot_factor_ic,
)

__all__ = [
    "set_qfbook_style",
    "plot_market_cap_distribution",
    "plot_industry_structure",
    "plot_turnover_analysis",
    "plot_cumulative_return",
    "plot_drawdown",
    "plot_factor_ic",
]
