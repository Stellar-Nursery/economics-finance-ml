"""
qfbook.viz.plots — 常用可视化函数
==================================
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def plot_market_cap_distribution(
    df: pd.DataFrame,
    save_path: str | None = None,
) -> plt.Figure:
    """
    绘制A股市值分布图（对数直方图 + 区间统计）。

    Parameters
    ----------
    df : pd.DataFrame
        需包含 'market_cap' 列（单位：元）。
    save_path : str, optional
        保存路径。
    """
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    market_cap_billion = df["market_cap"] / 1e8  # 亿元

    # 左图：对数直方图
    axes[0].hist(
        np.log10(market_cap_billion.dropna()),
        bins=50, color="#2E86AB", edgecolor="white", alpha=0.85,
    )
    axes[0].set_xlabel("log10(市值/亿元)")
    axes[0].set_ylabel("股票数量")
    axes[0].set_title("A股市值分布（对数坐标）")
    axes[0].axvline(np.log10(100), color="#E84855", ls="--", label="100亿")
    axes[0].axvline(np.log10(1000), color="#F5A623", ls="--", label="1000亿")
    axes[0].legend()

    # 右图：区间统计
    bins = [0, 30, 100, 500, 1000, 5000, np.inf]
    labels = ["<30亿", "30-100亿", "100-500亿", "500-1000亿", "1000-5000亿", ">5000亿"]
    df_temp = df.copy()
    df_temp["cap_group"] = pd.cut(market_cap_billion, bins=bins, labels=labels)
    counts = df_temp["cap_group"].value_counts().reindex(labels)
    colors = plt.cm.Blues(np.linspace(0.3, 0.9, len(labels)))
    axes[1].barh(labels, counts.values, color=colors, edgecolor="white")
    axes[1].set_xlabel("股票数量")
    axes[1].set_title("A股市值区间分布")

    total = len(df)
    for i, count in enumerate(counts.values):
        axes[1].text(count + total * 0.01, i, f"{count} ({count/total*100:.1f}%)",
                     va="center", fontsize=9)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, bbox_inches="tight", dpi=300)
    return fig


def plot_industry_structure(
    df: pd.DataFrame,
    top_n: int = 15,
    save_path: str | None = None,
) -> plt.Figure:
    """绘制A股行业结构图（公司数量 + 总市值）。"""
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    # 左图：公司数量
    industry_count = df["industry"].value_counts().head(top_n)
    axes[0].barh(
        industry_count.index[::-1], industry_count.values[::-1],
        color="#2E86AB", edgecolor="white",
    )
    axes[0].set_xlabel("上市公司数量")
    axes[0].set_title(f"各行业上市公司数量（前{top_n}）")

    # 右图：总市值
    industry_cap = df.groupby("industry")["market_cap"].sum()
    industry_cap = (industry_cap / 1e12).sort_values(ascending=False).head(top_n)
    axes[1].barh(
        industry_cap.index[::-1], industry_cap.values[::-1],
        color="#E84855", edgecolor="white",
    )
    axes[1].set_xlabel("总市值（万亿元）")
    axes[1].set_title(f"各行业总市值（前{top_n}）")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, bbox_inches="tight", dpi=300)
    return fig


def plot_turnover_analysis(
    df: pd.DataFrame,
    save_path: str | None = None,
) -> plt.Figure:
    """绘制换手率分析图（分布 + 市值关系）。"""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    turnover = df["turnover_rate"].dropna()

    # 左图：分布
    axes[0].hist(
        turnover[turnover < 20], bins=50,
        color="#2E86AB", edgecolor="white", alpha=0.85,
    )
    axes[0].set_xlabel("换手率 (%)")
    axes[0].set_ylabel("股票数量")
    axes[0].set_title("A股日换手率分布")
    axes[0].axvline(
        turnover.median(), color="#E84855", ls="--",
        label=f"中位数: {turnover.median():.2f}%",
    )
    axes[0].legend()

    # 右图：市值 vs 换手率
    market_cap_log = np.log10(df["market_cap"].dropna() / 1e8)
    axes[1].scatter(
        market_cap_log, df.loc[market_cap_log.index, "turnover_rate"],
        alpha=0.15, s=4, color="#2E86AB",
    )
    axes[1].set_xlabel("log10(市值/亿元)")
    axes[1].set_ylabel("换手率 (%)")
    axes[1].set_title("市值与换手率的关系")
    axes[1].set_ylim(0, 25)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, bbox_inches="tight", dpi=300)
    return fig


def plot_cumulative_return(
    returns: pd.Series | pd.DataFrame,
    benchmark: pd.Series | None = None,
    title: str = "累计收益",
    save_path: str | None = None,
) -> plt.Figure:
    """绘制累计收益曲线。"""
    fig, ax = plt.subplots(figsize=(12, 5))

    if isinstance(returns, pd.Series):
        cum = (1 + returns).cumprod() - 1
        ax.plot(cum.index, cum.values, label="策略", linewidth=1.5)
    else:
        for col in returns.columns:
            cum = (1 + returns[col]).cumprod() - 1
            ax.plot(cum.index, cum.values, label=col, linewidth=1.5)

    if benchmark is not None:
        cum_bm = (1 + benchmark).cumprod() - 1
        ax.plot(cum_bm.index, cum_bm.values, label="基准", color="gray",
                linewidth=1.2, ls="--")

    ax.set_title(title)
    ax.set_ylabel("累计收益率")
    ax.legend()
    ax.axhline(0, color="black", linewidth=0.5)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, bbox_inches="tight", dpi=300)
    return fig


def plot_drawdown(
    returns: pd.Series,
    title: str = "回撤分析",
    save_path: str | None = None,
) -> plt.Figure:
    """绘制回撤图。"""
    cum = (1 + returns).cumprod()
    running_max = cum.cummax()
    drawdown = (cum - running_max) / running_max

    fig, ax = plt.subplots(figsize=(12, 4))
    ax.fill_between(drawdown.index, drawdown.values, 0, color="#E84855", alpha=0.4)
    ax.plot(drawdown.index, drawdown.values, color="#E84855", linewidth=0.8)
    ax.set_title(title)
    ax.set_ylabel("回撤")
    ax.set_ylim(drawdown.min() * 1.1, 0.02)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, bbox_inches="tight", dpi=300)
    return fig


def plot_factor_ic(
    ic_series: pd.Series,
    title: str = "因子IC时序",
    save_path: str | None = None,
) -> plt.Figure:
    """绘制因子IC时序图（柱状图 + 累计IC曲线）。"""
    fig, ax1 = plt.subplots(figsize=(12, 5))

    colors = ["#2E86AB" if v >= 0 else "#E84855" for v in ic_series.values]
    ax1.bar(ic_series.index, ic_series.values, color=colors, alpha=0.6, width=20)
    ax1.set_ylabel("IC")
    ax1.axhline(0, color="black", linewidth=0.5)

    ax2 = ax1.twinx()
    cum_ic = ic_series.cumsum()
    ax2.plot(cum_ic.index, cum_ic.values, color="#F5A623", linewidth=2, label="累计IC")
    ax2.set_ylabel("累计IC")
    ax2.legend(loc="upper left")

    mean_ic = ic_series.mean()
    ic_ir = mean_ic / ic_series.std() if ic_series.std() > 0 else 0
    ax1.set_title(f"{title}  |  IC均值={mean_ic:.4f}  ICIR={ic_ir:.2f}")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, bbox_inches="tight", dpi=300)
    return fig
