"""
qfbook.config — 全局配置
=========================

集中管理项目路径、默认参数等配置项。
"""

import os
from pathlib import Path

# ---------------------------------------------------------------------------
#  路径配置
# ---------------------------------------------------------------------------


def _find_project_root() -> Path:
    """定位项目根目录（即 data/ 与 figures/ 所在的那一层）。

    本包在两种布局下使用，config.py 的嵌套深度不同：

        仓库：      <root>/qfbook/qfbook/config.py
        学生资料包： <root>/qfbook/config.py

    因此不能按固定层数上溯，改为向上查找第一个含 data/ 的祖先目录。
    搜索从「包所在目录的上一层」开始——本包自己就有 qfbook/data/ 子包，
    从包内起步会立刻命中它。
    环境变量 QFBOOK_PROJECT_ROOT 可覆盖自动探测，便于把数据放在别处。
    """
    override = os.environ.get("QFBOOK_PROJECT_ROOT")
    if override:
        return Path(override).expanduser().resolve()

    package_dir = Path(__file__).resolve().parent
    for candidate in package_dir.parents:
        if (candidate / "data").is_dir():
            return candidate
    # 找不到标志目录时退回仓库布局的层级，保持旧行为。
    return package_dir.parents[1]


# 项目根目录
PROJECT_ROOT = _find_project_root()

# 数据目录
DATA_DIR = PROJECT_ROOT / "data"
DATA_RAW_DIR = DATA_DIR / "raw"
DATA_PROCESSED_DIR = DATA_DIR / "processed"
DATA_OFFLINE_DIR = DATA_DIR / "offline"

# 图片输出目录
FIGURES_DIR = PROJECT_ROOT / "figures"

# ---------------------------------------------------------------------------
#  默认参数
# ---------------------------------------------------------------------------

# 有效股票池筛选参数
DEFAULT_MIN_AMOUNT = 1e7          # 日均成交额下限（元）
DEFAULT_EXCLUDE_NEW_DAYS = 120    # 次新股排除天数

# 因子研究默认参数
DEFAULT_IC_METHOD = "rank"        # IC 计算方法: "rank" 或 "normal"
DEFAULT_N_GROUPS = 5              # 分组回测的组数

# 回测默认参数
DEFAULT_COMMISSION = 0.0002       # 佣金率（单边）
DEFAULT_STAMP_TAX = 0.0005        # 印花税（卖出时）
DEFAULT_SLIPPAGE = 0.0008         # 冲击成本（单边）
DEFAULT_TRADE_COST = (            # 单边总交易成本
    DEFAULT_COMMISSION + DEFAULT_STAMP_TAX / 2 + DEFAULT_SLIPPAGE
)

# 常用指数代码
INDEX_HS300 = "000300"            # 沪深300
INDEX_ZZ500 = "000905"            # 中证500
INDEX_ZZ1000 = "000852"           # 中证1000
