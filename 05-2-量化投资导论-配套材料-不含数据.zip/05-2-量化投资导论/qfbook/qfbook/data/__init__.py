"""
qfbook.data -- Data loading & preprocessing
=============================================

Unified data loading interface supporting offline (Parquet) mode.
"""

from qfbook.data.loader import (
    get_data_dir,
    # Stock info
    load_stock_basic,
    load_stock_info,
    # Daily market data
    load_daily_prices,
    load_adj_factor,
    load_daily_basic,
    # Index data
    load_index_daily,
    load_index_weights,
    # Financial statements
    load_income,
    load_balancesheet,
    load_cashflow,
    load_fina_indicator,
    load_financial_data,
    # Interest rates
    load_shibor,
    # Industry
    load_industry_class,
    # Supplementary (delisted names / suspensions / price limits)
    load_namechange,
    load_suspend,
    load_stk_limit,
)

__all__ = [
    "get_data_dir",
    "load_stock_basic",
    "load_stock_info",
    "load_daily_prices",
    "load_adj_factor",
    "load_daily_basic",
    "load_index_daily",
    "load_index_weights",
    "load_income",
    "load_balancesheet",
    "load_cashflow",
    "load_fina_indicator",
    "load_financial_data",
    "load_shibor",
    "load_industry_class",
    "load_namechange",
    "load_suspend",
    "load_stk_limit",
]
