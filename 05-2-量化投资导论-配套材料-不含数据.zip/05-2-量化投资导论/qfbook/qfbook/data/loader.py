"""
qfbook.data.loader -- Unified data loading interface
=====================================================

Design:
1. Default: offline Parquet files (reproducibility)
2. All functions return pandas DataFrame with English column names
3. Tushare ts_code format: '000001.SZ' -> stripped to '000001' when needed
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import pandas as pd

# ---------------------------------------------------------------------------
#  Path management
# ---------------------------------------------------------------------------

_DEFAULT_DATA_DIR = Path(__file__).resolve().parents[3] / "data" / "offline"


def get_data_dir() -> Path:
    """Return offline data directory. Env var QFBOOK_DATA_DIR overrides."""
    env = os.environ.get("QFBOOK_DATA_DIR")
    return Path(env) if env else _DEFAULT_DATA_DIR


def _read(name: str, data_dir: Path | None = None) -> pd.DataFrame:
    """Read a Parquet file from the data directory."""
    d = Path(data_dir) if data_dir else get_data_dir()
    fp = d / f"{name}.parquet"
    if not fp.exists():
        raise FileNotFoundError(
            f"Offline data not found: {fp}\n"
            "Run: python scripts/prepare_data.py"
        )
    return pd.read_parquet(fp)


# ---------------------------------------------------------------------------
#  Stock basic info
# ---------------------------------------------------------------------------

def load_stock_basic(data_dir: Optional[str | Path] = None) -> pd.DataFrame:
    """
    Load A-share stock basic info.

    Returns
    -------
    pd.DataFrame
        ts_code, symbol, name, area, industry, market, list_date, ...
    """
    return _read("stock_basic", data_dir)


def load_stock_info(
    offline: bool = True,
    data_dir: Optional[str | Path] = None,
) -> pd.DataFrame:
    """
    Load A-share stock info (backward-compatible interface).

    Tries new Tushare format first, falls back to legacy format.

    Returns
    -------
    pd.DataFrame
        With columns: code, name, market_cap, float_market_cap,
        industry, list_date, turnover_rate, close, pct_change, ...
    """
    d = Path(data_dir) if data_dir else get_data_dir()

    # Try new Tushare format (stock_basic + daily_basic)
    sb_fp = d / "stock_basic.parquet"
    # 05-2材料将最新截面与两列换手率历史分开保存；计算逻辑保持原样。
    snapshot_fp = d / "daily_basic_snapshot.parquet"
    db_fp = snapshot_fp if snapshot_fp.exists() else d / "daily_basic.parquet"

    if sb_fp.exists() and db_fp.exists():
        sb = pd.read_parquet(sb_fp)
        # Get latest snapshot from daily_basic
        db = pd.read_parquet(db_fp)
        latest_date = db["trade_date"].max()
        db_latest = db[db["trade_date"] == latest_date].copy()

        # Merge
        df = sb.merge(db_latest, on="ts_code", how="left")

        # Rename to legacy column names
        col_map = {
            "symbol": "code",
            "total_mv": "market_cap",
            "circ_mv": "float_market_cap",
            "turnover_rate": "turnover_rate",
            "pe_ttm": "pe_ttm",
            "pb": "pb",
        }
        df = df.rename(columns=col_map)

        # total_mv and circ_mv are in 10k yuan in Tushare -> convert to yuan
        if "market_cap" in df.columns:
            df["market_cap"] = df["market_cap"] * 1e4
        if "float_market_cap" in df.columns:
            df["float_market_cap"] = df["float_market_cap"] * 1e4

        # Enrich with daily trading data (amount, volume, pct_chg)
        # for filter_investable_universe and analysis
        daily_fp = d / "daily.parquet"
        if daily_fp.exists():
            daily = pd.read_parquet(daily_fp)
            dl = daily[daily["trade_date"] == latest_date].copy()
            # Compute 20-day average amount for liquidity filtering
            recent_20 = daily[daily["trade_date"] > str(int(latest_date) - 100)]
            avg_amt = (
                recent_20.groupby("ts_code")["amount"]
                .mean()
                .reset_index()
                .rename(columns={"amount": "avg_amount_20d"})
            )
            # amount in daily.parquet is in 1000 yuan -> convert to yuan
            avg_amt["avg_amount_20d"] = avg_amt["avg_amount_20d"] * 1e3

            # Latest day amount & volume
            dl_cols = dl[["ts_code", "vol", "amount", "pct_chg"]].copy()
            dl_cols["amount"] = dl_cols["amount"] * 1e3  # to yuan
            dl_cols = dl_cols.rename(columns={"vol": "volume"})

            df = df.merge(dl_cols, on="ts_code", how="left")
            df = df.merge(avg_amt, on="ts_code", how="left")

        return df

    # Fallback: legacy format (from akshare or generate_sample_data)
    legacy_fp = d / "stock_info.parquet"
    if legacy_fp.exists():
        return pd.read_parquet(legacy_fp)

    raise FileNotFoundError(
        f"No stock info data found in {d}\n"
        "Run: python scripts/prepare_data.py"
    )


# ---------------------------------------------------------------------------
#  Daily prices
# ---------------------------------------------------------------------------

def load_daily_prices(
    start_date: str = "2015-01-01",
    end_date: Optional[str] = None,
    data_dir: Optional[str | Path] = None,
) -> pd.DataFrame:
    """
    Load daily OHLCV data.

    Returns
    -------
    pd.DataFrame
        Columns: ts_code, trade_date, open, high, low, close,
        pre_close, change, pct_chg, vol, amount
    """
    df = _read("daily", data_dir)
    sd = start_date.replace("-", "")
    mask = df["trade_date"] >= sd
    if end_date:
        mask &= df["trade_date"] <= end_date.replace("-", "")
    return df.loc[mask].copy()


# ---------------------------------------------------------------------------
#  Adjustment factors
# ---------------------------------------------------------------------------

def load_adj_factor(
    start_date: str = "2015-01-01",
    end_date: Optional[str] = None,
    data_dir: Optional[str | Path] = None,
) -> pd.DataFrame:
    """
    Load adjustment factors.

    Returns
    -------
    pd.DataFrame
        Columns: ts_code, trade_date, adj_factor
    """
    df = _read("adj_factor", data_dir)
    sd = start_date.replace("-", "")
    mask = df["trade_date"] >= sd
    if end_date:
        mask &= df["trade_date"] <= end_date.replace("-", "")
    return df.loc[mask].copy()


# ---------------------------------------------------------------------------
#  Daily basic metrics
# ---------------------------------------------------------------------------

def load_daily_basic(
    start_date: str = "2015-01-01",
    end_date: Optional[str] = None,
    data_dir: Optional[str | Path] = None,
) -> pd.DataFrame:
    """
    Load daily basic metrics (market cap, PE, PB, turnover, etc.).

    Returns
    -------
    pd.DataFrame
        Columns: ts_code, trade_date, close, turnover_rate, pe_ttm,
        pb, total_mv, circ_mv, ...
    """
    df = _read("daily_basic", data_dir)
    sd = start_date.replace("-", "")
    mask = df["trade_date"] >= sd
    if end_date:
        mask &= df["trade_date"] <= end_date.replace("-", "")
    return df.loc[mask].copy()


# ---------------------------------------------------------------------------
#  Index daily
# ---------------------------------------------------------------------------

def load_index_daily(
    index_code: str = "000300.SH",
    start_date: str = "2015-01-01",
    end_date: Optional[str] = None,
    data_dir: Optional[str | Path] = None,
) -> pd.DataFrame:
    """
    Load index daily prices.

    Parameters
    ----------
    index_code : str
        '000300.SH' (CSI300), '000905.SH' (CSI500),
        '000852.SH' (CSI1000), '000001.SH' (SSE Composite), etc.
    """
    df = _read("index_daily", data_dir)
    mask = df["ts_code"] == index_code
    sd = start_date.replace("-", "")
    mask &= df["trade_date"] >= sd
    if end_date:
        mask &= df["trade_date"] <= end_date.replace("-", "")
    return df.loc[mask].copy()


# ---------------------------------------------------------------------------
#  Index weights
# ---------------------------------------------------------------------------

def load_index_weights(
    index_code: str = "000905.SH",
    data_dir: Optional[str | Path] = None,
) -> pd.DataFrame:
    """
    Load index constituent weights.

    Parameters
    ----------
    index_code : str
        '000300.SH', '000905.SH', '000852.SH'
    """
    d = Path(data_dir) if data_dir else get_data_dir()

    # New format (single file with all indices)
    new_fp = d / "index_weight.parquet"
    if new_fp.exists():
        df = pd.read_parquet(new_fp)
        return df[df["index_code"] == index_code].copy()

    # Legacy format (separate files per index)
    code_short = index_code.split(".")[0]
    legacy_fp = d / f"index_weights_{code_short}.parquet"
    if legacy_fp.exists():
        return pd.read_parquet(legacy_fp)

    raise FileNotFoundError(f"Index weight data not found for {index_code}")


# ---------------------------------------------------------------------------
#  Financial statements
# ---------------------------------------------------------------------------

def load_income(data_dir: Optional[str | Path] = None) -> pd.DataFrame:
    """Load income statement data."""
    return _read("income", data_dir)


def load_balancesheet(data_dir: Optional[str | Path] = None) -> pd.DataFrame:
    """Load balance sheet data."""
    return _read("balancesheet", data_dir)


def load_cashflow(data_dir: Optional[str | Path] = None) -> pd.DataFrame:
    """Load cash flow statement data."""
    return _read("cashflow", data_dir)


def load_fina_indicator(data_dir: Optional[str | Path] = None) -> pd.DataFrame:
    """
    Load financial indicators (ROE, margins, growth rates, etc.).

    Key columns:
        roe, roe_waa, roa, grossprofit_margin, netprofit_margin,
        assets_turn, current_ratio, quick_ratio,
        q_sales_yoy, q_profit_yoy, tr_yoy, eps, bps
    """
    return _read("fina_indicator", data_dir)


def load_financial_data(
    offline: bool = True,
    data_dir: Optional[str | Path] = None,
) -> pd.DataFrame:
    """Backward-compatible: load financial indicators."""
    d = Path(data_dir) if data_dir else get_data_dir()

    fi_fp = d / "fina_indicator.parquet"
    if fi_fp.exists():
        return pd.read_parquet(fi_fp)

    # Legacy fallback
    legacy_fp = d / "financial_data.parquet"
    if legacy_fp.exists():
        return pd.read_parquet(legacy_fp)

    raise FileNotFoundError("No financial data found. Run prepare_data.py")


# ---------------------------------------------------------------------------
#  Industry classification
# ---------------------------------------------------------------------------

def load_shibor(
    start_date: str = "2005-01-01",
    end_date: Optional[str] = None,
    data_dir: Optional[str | Path] = None,
) -> pd.DataFrame:
    """
    Load Shibor interest rate data.

    Returns
    -------
    pd.DataFrame
        Columns: date, on (overnight), 1w, 2w, 1m, 3m, 6m, 9m, 1y
    """
    df = _read("shibor", data_dir)
    sd = start_date.replace("-", "")
    mask = df["date"] >= sd
    if end_date:
        mask &= df["date"] <= end_date.replace("-", "")
    return df.loc[mask].copy()


def load_industry_class(
    standard: str = "sw",
    offline: bool = True,
    data_dir: Optional[str | Path] = None,
) -> pd.DataFrame:
    """Load industry classification."""
    return _read(f"industry_{standard}", data_dir)


# ---------------------------------------------------------------------------
#  Supplementary data (added 2026-07: delisted names / suspensions / limits)
# ---------------------------------------------------------------------------

def load_namechange(data_dir: Optional[str | Path] = None) -> pd.DataFrame:
    """
    Load historical name changes (identifies historical ST status).

    Returns
    -------
    pd.DataFrame
        Columns: ts_code, name, start_date, end_date, ann_date, change_reason.
        A stock was ST on date d if its effective name on d contains 'ST'
        (match rows with start_date <= d <= end_date).
    """
    return _read("namechange", data_dir)


def load_suspend(
    start_date: str = "2015-01-01",
    end_date: Optional[str] = None,
    data_dir: Optional[str | Path] = None,
) -> pd.DataFrame:
    """
    Load suspension/resumption records.

    Returns
    -------
    pd.DataFrame
        Columns: ts_code, trade_date, suspend_timing, suspend_type
        (suspend_type: 'S' = suspended, 'R' = resumed).
    """
    df = _read("suspend_d", data_dir)
    sd = start_date.replace("-", "")
    mask = df["trade_date"] >= sd
    if end_date:
        mask &= df["trade_date"] <= end_date.replace("-", "")
    return df.loc[mask].copy()


def load_stk_limit(
    start_date: str = "2015-01-01",
    end_date: Optional[str] = None,
    data_dir: Optional[str | Path] = None,
) -> pd.DataFrame:
    """
    Load daily price limits (limit-up / limit-down prices).

    Returns
    -------
    pd.DataFrame
        Columns: trade_date, ts_code, up_limit, down_limit.
        Typical tradability filter: cannot buy if close >= up_limit * 0.99,
        cannot sell if close <= down_limit * 1.01.
    """
    df = _read("stk_limit", data_dir)
    sd = start_date.replace("-", "")
    mask = df["trade_date"] >= sd
    if end_date:
        mask &= df["trade_date"] <= end_date.replace("-", "")
    return df.loc[mask].copy()
