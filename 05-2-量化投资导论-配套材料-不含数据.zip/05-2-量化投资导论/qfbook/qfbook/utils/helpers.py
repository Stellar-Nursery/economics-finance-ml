"""
qfbook.utils.helpers — 通用工具函数
=====================================
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def filter_investable_universe(
    df: pd.DataFrame,
    min_amount: float = 1e7,
    exclude_st: bool = True,
    exclude_new_days: int = 120,
    verbose: bool = False,
) -> pd.DataFrame:
    """
    构建有效股票池，剔除不适合量化交易的股票。

    Parameters
    ----------
    df : pd.DataFrame
        A股全部上市公司信息，需包含 'name', 'amount' (或 'avg_amount_20d') 列。
    min_amount : float
        日均成交额下限（元），默认 1000 万。
    exclude_st : bool
        是否剔除 ST/*ST 股票。
    exclude_new_days : int
        剔除上市不满多少天的次新股。
    verbose : bool
        是否打印筛选过程。

    Returns
    -------
    pd.DataFrame
        筛选后的有效股票池。
    """
    total = len(df)
    result = df.copy()

    if verbose:
        print(f"{'='*50}")
        print(f"A股有效股票池构建过程")
        print(f"{'='*50}")
        print(f"初始股票数量: {total}")

    # 1. 剔除 ST
    if exclude_st and "name" in result.columns:
        mask = result["name"].str.contains("ST", na=False)
        n = mask.sum()
        result = result[~mask]
        if verbose:
            print(f"剔除ST/*ST:   -{n:>4d}  (剩余 {len(result)})")

    # 2. 剔除次新股
    if "list_date" in result.columns and exclude_new_days > 0:
        from datetime import datetime, timedelta
        cutoff = datetime.now() - timedelta(days=exclude_new_days)
        # list_date may be 'YYYYMMDD' string or datetime
        dates = pd.to_datetime(result["list_date"], format="mixed", errors="coerce")
        mask = dates > cutoff
        n = mask.sum()
        result = result[~mask]
        if verbose:
            print(f"剔除次新股:   -{n:>4d}  (剩余 {len(result)})")

    # 3. 剔除停牌（volume==0 或 turnover_rate==0 或 NaN in market_cap）
    vol_col = None
    for c in ["volume", "vol"]:
        if c in result.columns:
            vol_col = c
            break
    if vol_col:
        mask = (result[vol_col] == 0) | result[vol_col].isna()
        n = mask.sum()
        result = result[~mask]
        if verbose:
            print(f"剔除停牌股:   -{n:>4d}  (剩余 {len(result)})")
    elif "turnover_rate" in result.columns:
        mask = (result["turnover_rate"] == 0) | result["turnover_rate"].isna()
        n = mask.sum()
        result = result[~mask]
        if verbose:
            print(f"剔除停牌股:   -{n:>4d}  (剩余 {len(result)})")

    # 4. 剔除低流动性
    amt_col = None
    for c in ["avg_amount_20d", "amount"]:
        if c in result.columns:
            amt_col = c
            break
    if amt_col:
        mask = result[amt_col].isna() | (result[amt_col] < min_amount)
        n = mask.sum()
        result = result[~mask]
        if verbose:
            print(f"剔除低流动性: -{n:>4d}  (剩余 {len(result)})")

    if verbose:
        n_removed = total - len(result)
        print(f"{'='*50}")
        print(f"有效股票池:    {len(result)} 只 "
              f"(剔除 {n_removed} 只, 占比 {n_removed/total*100:.1f}%)")
        print(f"{'='*50}")

    return result


def compute_returns(
    prices: pd.DataFrame | pd.Series,
    periods: int = 1,
) -> pd.DataFrame | pd.Series:
    """
    计算收益率。

    Parameters
    ----------
    prices : pd.DataFrame or pd.Series
        价格数据。
    periods : int
        收益率计算周期（天数）。

    Returns
    -------
    pd.DataFrame or pd.Series
        收益率。
    """
    return prices.pct_change(periods=periods)


def winsorize(
    series: pd.Series,
    method: str = "mad",
    k: float = 5.0,
) -> pd.Series:
    """
    去极值处理。

    Parameters
    ----------
    series : pd.Series
        原始数据。
    method : str
        'mad'：中位数 ± k×MAD（华泰口径，与 qfbook.factor.single_test.mad_winsorize 相同）；
        'sigma'：均值 ± k×标准差。
    k : float
        截断倍数。

    Returns
    -------
    pd.Series
        去极值后的数据。
    """
    s = series.copy()
    if method == "mad":
        median = s.median()
        mad = (s - median).abs().median()
        upper = median + k * mad
        lower = median - k * mad
    elif method == "sigma":
        mean = s.mean()
        std = s.std()
        upper = mean + k * std
        lower = mean - k * std
    else:
        raise ValueError(f"Unknown method: {method}")

    return s.clip(lower=lower, upper=upper)


def zscore_normalize(series: pd.Series) -> pd.Series:
    """
    Z-score 标准化。

    Parameters
    ----------
    series : pd.Series
        原始数据。

    Returns
    -------
    pd.Series
        标准化后的数据（均值0，标准差1）。
    """
    std = series.std()
    if std == 0 or pd.isna(std):
        return series * 0
    return (series - series.mean()) / std
