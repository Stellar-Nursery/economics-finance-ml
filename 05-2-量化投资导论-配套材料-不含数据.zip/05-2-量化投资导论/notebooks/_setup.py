"""课程 Notebook 的公共准备工作。

每份 Notebook 的第一格执行 ``import _setup`` 即可，它做三件事：

1. 让 Python 找到课程自带的 ``qfbook`` 工具库——它就在资料包根目录下的 ``qfbook/``，
   不需要 ``pip install``；
2. 统一图表风格（中文字体、配色、字号）；
3. 建好图表输出目录 ``figures/``（位于资料包根目录）；
4. 屏蔽第三方库的版本弃用提示（FutureWarning / DeprecationWarning）。这类提示只与库的
   未来版本有关，与课程内容无关；其余警告（如数值计算中的 RuntimeWarning）照常显示。

前提：本文件与 Notebook 同在 ``notebooks/`` 目录，并从该目录启动 Jupyter，
或直接在 VS Code / Cursor 中打开这里的 ``.ipynb`` 文件。

学生不需要修改本文件。
"""

import logging
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)
# 课程字体 SimHei 没有粗体，matplotlib 每次回退都会记一条日志，这里只保留错误级别
logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)

# notebooks/ 的上一级就是资料包（或课程仓库）的根目录
_ROOT = Path(__file__).resolve().parent.parent

# 资料包是扁平布局：根目录/qfbook/__init__.py；
# 课程仓库是嵌套布局：根目录/qfbook/qfbook/__init__.py。两种都支持。
if (_ROOT / "qfbook" / "__init__.py").exists():
    _PKG_PARENT = _ROOT
elif (_ROOT / "qfbook" / "qfbook" / "__init__.py").exists():
    _PKG_PARENT = _ROOT / "qfbook"
else:
    _PKG_PARENT = _ROOT

if str(_PKG_PARENT) not in sys.path:
    sys.path.insert(0, str(_PKG_PARENT))

from qfbook.config import DATA_OFFLINE_DIR, FIGURES_DIR  # noqa: E402
from qfbook.viz.style import set_qfbook_style  # noqa: E402

set_qfbook_style()
FIGURES_DIR.mkdir(parents=True, exist_ok=True)

# 离线数据尚未放到位时给出提示，而不是等到第一次读数据才报一长串错误
if not any(DATA_OFFLINE_DIR.glob("*.parquet")):
    print(
        "提示：尚未找到离线数据（{} 下没有 .parquet 文件）。\n"
        "可以先阅读各格保存的运行结果；数据下载与放置方式见《使用说明》。".format(
            DATA_OFFLINE_DIR
        )
    )
