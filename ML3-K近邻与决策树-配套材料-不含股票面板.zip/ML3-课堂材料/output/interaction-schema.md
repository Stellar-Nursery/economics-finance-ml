# 股票预测与银行营销案例的结果字段

股票案例预测下一持有期的开盘到开盘收益率。银行案例预测客户认购定期存款的概率。两项任务各自划分样本，使用不同的评价指标。

## 股票案例的数据与样本

[交互结果](interaction-data.json)的 `sample_summary` 记录各阶段样本。每条数据对应一个股票月。`initial_train` 和 `final_refit` 分别为初次训练和确定参数后重新拟合时使用的记录数。股票行业、市值及盈利收益率等特征进入同一组 36 列模型输入。

| 阶段 | 可预测的记录 | 有收益标签、可评价的记录 |
| --- | ---: | ---: |
| 验证期 | 103,017（`validation_predict`） | 102,813（`validation_eval`） |
| 教学测试期 | 128,148（`teaching_test_predict`） | 127,949（`teaching_test_eval`） |

`source_rows` 为输入面板行数，`design_columns` 为模型输入列数。初次训练和最终重拟合分别使用 125,747 和 231,178 条记录。`input_sha256` 可与[数据来源清单](../data/source-manifest.json)中的股票面板校验值核对。`schema_version`、`status`、`generated_at` 分别标识数据格式、计算状态和生成时间。`runtime` 记录近邻搜索与完整计算所用的秒数。

## 模型选择和评价

[近邻候选表](knn-grid.csv)列出 14 组邻居数与权重方式，[回归树候选表](tree-grid.csv)列出 75 组深度、最小叶样本占比与剪枝参数。`candidate_id` 标识参数组合，`val_mse` 为该组合的验证均方误差。`selection.knn` 和 `selection.tree` 是按验证误差选定的设定，`selection.ridge_lambda` 为岭回归选定的惩罚系数。模型使用冻结设定进入教学测试。

[模型指标表](stock-model-metrics.csv)与 `metrics` 均按模型和阶段汇总。每种模型在验证期（`validation`）和教学测试期（`teaching_test`）各占一行。收益率以小数记录。

| 字段 | 怎样读 |
| --- | --- |
| `model`、`stage` | 模型名称和评价阶段 |
| `n_predict`、`n_evaluable`、`n_months` | 得到预测的记录数、预测与标签均有效的记录数、该阶段的月份数 |
| `mse`、`rmse`、`mae` | 均方误差、均方根误差、平均绝对误差。均方误差的单位为收益率小数的平方 |
| `r2_frozen_mean` | 以该阶段固定的训练均值作为预测基准，在相同评价样本上比较平方误差总和所得的相对 R² |
| `mean_ic`、`mean_rank_ic` | 先在同月股票之间计算预测与实际收益的 Pearson 相关系数或秩相关系数，再对有效月份等权平均 |
| `n_ic_months`、`n_rank_ic_months` | 相应相关系数有定义的月份数 |

[逐月指标表](stock-monthly-metrics.csv)用 `ym` 表示年月，用 `ic`、`rank_ic` 表示该月的两种相关系数，含验证期和教学测试期的全部月份。`monthly` 只收录教学测试期的 36 个月。冻结均值基准（`FrozenMean`）在同月对所有股票给出相同预测，相关系数无定义。`EP_score` 是排序分数，比较排序时可读取逐月 `rank_ic` 并对有效月份取平均。该分数与收益率量纲不同，不参与收益预测误差比较。

## 从一条预测追溯到训练数据

[股票预测样例](examples.json)与 `examples` 内容相同，包含 2023 年 1 月、2024 年 1 月、2025 年 1 月和 2025 年 12 月各三条股票记录。`row_key` 由年月和股票代码组成。它把同一股票月的实际收益 `y` 与近邻、回归树、普通最小二乘的预测 `pred_knn`、`pred_tree`、`pred_ols` 联系起来。

- **近邻预测。** `neighbors` 列出用于这条预测的全部邻居。每个邻居有股票代码 `ts_code`、名称 `name`、年月 `ym`、已实现收益 `y` 和在标准化特征空间中的距离 `distance`。`weight` 是归一化权重，乘以该邻居的收益得到 `contribution`。将全部贡献相加即可复算 `pred_knn`。
- **回归树预测。** `tree_path` 按从根到叶的顺序列出各次分裂。`feature` 为特征，`value` 为本条记录的特征值，`threshold` 为切分点，`direction` 为实际分支，`n` 是到达该节点的训练记录数。`leaf_n` 为终端叶的训练记录数，`leaf_mean` 为这些记录的平均收益，即 `pred_tree`。
- **变量重要性。** `mdi_top` 按训练中带来的加权不纯度下降列出最终回归树的前 12 个特征。`mdi_grouped` 分别汇总基础项、平方项、交互项和行业列的贡献。

## 银行营销分类

[银行分类结果](bank-classification.json)记录 4,119 条银行联系记录的样本分布、树的参数与分类指标。`n_train`、`n_val`、`n_test` 对应 2,495 条训练记录、624 条验证记录、1,000 条测试记录。`yes` 与 `no` 为两类实际人数。银行数据表中有两个时间含义不同的字段。

| 原始列名 | 含义及在本案例中的用法 |
| --- | --- |
| `nr.employed` | 葡萄牙的季度就业人数，反映银行联系客户时的宏观经济环境。同一季度的记录共享该指标。 |
| `duration` | 本次通话的时长（秒）。拨号前无法知道，建模时排除。 |

[银行分类候选表](bank-grid.csv)列出 64 组参数及验证 Brier 分数。Brier 分数为预测认购概率与实际 0/1 标签间的均方误差。`selected` 记录所选参数，`grid_head` 列出验证 Brier 分数最低的八组设定，`importances` 列出最终树的前 12 个特征及其重要性。

`validation.prob_yes` 和 `validation.y` 按相同顺序列出每条验证记录的认购概率和真实标签。预测概率达到阈值时判为认购。可以调整验证阈值，复算真阳性（`tp`）、假阳性（`fp`）、真阴性（`tn`）和假阴性（`fn`）。`thr_0.1` 与 `thr_0.5` 分别给出两档阈值下的混淆计数、准确率、精确率、召回率、特异度、F1 与联系比例。教学测试结果同样按这两档阈值读取。

`brier`、`auc` 和 `ap` 分别为 Brier 分数、ROC 曲线下面积和平均精确率。这三项直接使用预测概率，固定预测概率时，改变行动阈值不会改变它们。[交互结果](interaction-data.json)中的 `bank` 汇总所选参数、验证与测试指标以及变量重要性。
