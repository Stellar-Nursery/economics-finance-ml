# ML3：K近邻与决策树课堂材料

打开[投影课件](slides-ml3.html)，配合 [ML3 Notebook](notebooks/ML3-K近邻与决策树.ipynb)，按课件页序阅读并从头运行。可按页码查找定义、图表和公式。代码单元复算模拟、读取课程试算结果，并检查样本数和预测分解。完整模型重算入口是 <code>scripts/compute_models.py</code>。

| 课件页 | Notebook 主题 |
| --- | --- |
| 1–4 | 导入 |
| 5–24 | K 近邻 |
| 25–59 | 决策树 |
| 60–62 | 银行营销分类与联系阈值 |
| 63–65 | 股票样本、时间窗口与模型选参 |
| 66–68 | 个股预测与整棵树的特征贡献 |
| 69–71 | 测试期评价与下一讲 |
| 72–74 | 数学附录 |
| 75–76 | 参考与致谢 |

## 运行

本包可直接阅读课件、交互网页与 Notebook 的已有输出，也可运行近邻模拟、决策树和银行分类练习。运行第 63 页的股票面板核验单元及后续股票练习前，将教师提供的 `ML3-K近邻与决策树-课堂数据.zip` 解压，将其中的 `ML3-课堂材料/data/ep_ml_panel.parquet` 放入本包同名目录的 `data/` 中。已有 ML1 课堂数据的同学也可复制 `ep_ml1_panel.parquet` 到此位置，并命名为 `ep_ml_panel.parquet`。Notebook 会校验文件的 SHA-256。

在本 README 所在目录启动 JupyterLab 或 VS Code，选择已安装依赖的 Python 内核，打开 Notebook 后按单元运行。数据与计算均在本地完成。

```sh
python -m pip install -r requirements.txt
```

输入只读。输出已写入 `output/` 与 `figures/`。若需要重算，在安装 `pyarrow` 的环境中运行 `python3 scripts/compute_models.py`。脚本按本课堂材料目录定位 `data/`，不依赖机器上的绝对路径。全量精确 KNN 搜索耗时较长，断点缓存保存在本目录的 `knn-cache/`，课堂页读取已经算好的邻居，不在浏览器里重搜。

## 文件

| 位置 | 内容 |
| --- | --- |
| `notebooks/ML3-K近邻与决策树.ipynb` | 课件逐页阅读、模拟复算与案例核验 |
| `data/ep_ml_panel.parquet` | 教师另行提供的课程正盈利股票面板 |
| `data/bank-additional.csv` | 银行营销 10% 子样本，建模时剔除通话时长 |
| `data/source-manifest.json` | 来源与 SHA-256 |
| `output/stock-model-metrics.csv` | 个股任务各阶段指标 |
| `output/knn-grid.csv` | 14 个 KNN 候选的验证 MSE |
| `output/tree-grid.csv` | 75 个回归树候选的验证 MSE |
| `output/stock-monthly-metrics.csv` | 逐月误差与 Rank IC |
| `output/bank-classification.json` | 银行分类选择、两档阈值与指标 |
| `output/interaction-data.json` | 交互页使用的结构化结果 |
| `figures/` | 近邻、决策树、银行分类与股票预测图表 |
| [离线交互](web/ML3-K近邻与决策树-交互.html) | K 近邻与决策树知识点、模拟实验、银行与股票案例 |

## 学习任务

1. 说明 KNN 的邻域由特征距离决定，不读取训练标签来画圈。
2. 解释为什么含自身的训练 MSE 不能决定最优 K。
3. 用 5/5、2/8、0/10 三组计数计算 Gini 和熵，再说明样本量不同时怎样加权。
4. 指出同一矩形对应树上的哪一片叶，叶内预测为什么相同。
5. 对同一条股票记录，列出 KNN 邻居与回归树路径，说明两者分别用了哪些历史信息。
6. 把银行案例的概率模型和行动阈值分开：测试只读事先固定的 0.1 与 0.5。

完成练习时，请用自己的话解释代码输出，并指出支持你判断的数值。

## 数据与结果边界

- 个股任务使用课程正盈利股票面板的 36 列特征，训练、验证与测试按时间划分。
- 平方损失下，回归树用该叶的训练标签均值预测。
- 银行在拨号前估计客户的订购概率，因此模型排除本次通话时长。银行数据的列名和含义见[银行营销字段说明](output/interaction-schema.md#银行营销分类)。
- EP_score 只用于排序，可由逐月表计算平均 Rank IC。FrozenMean 的预测恒定，Rank IC 未定义。
- 教学测试曾用于课程比较。净值、扣费收益和夏普需另行指定交易规则与成本。

银行数据由 S. Moro、P. Rita 与 P. Cortez 提供（2014）。包内使用 UCI 发布的 4,119 条记录子样本 `bank-additional.csv`，建模时排除通话时长。[Bank Marketing 数据集](https://doi.org/10.24432/C5K306) · [CC BY 4.0 许可](https://creativecommons.org/licenses/by/4.0/)。
