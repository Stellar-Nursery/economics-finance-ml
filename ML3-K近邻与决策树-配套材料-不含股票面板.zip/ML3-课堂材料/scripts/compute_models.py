#!/usr/bin/env python3
"""Fit ML3 KNN / Tree / bank models on the fifth-lecture panel and bank CSV."""
from __future__ import annotations

import hashlib
import json
import math
import time
from datetime import datetime, timezone
from itertools import product
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.metrics import (
    average_precision_score, brier_score_loss, confusion_matrix,
    f1_score, precision_score, recall_score, roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor

MATERIALS = Path(__file__).resolve().parents[1]
DATA = MATERIALS / "data"
OUT = MATERIALS / "output"
CHECKS = MATERIALS / "checks"
CACHE = MATERIALS / "knn-cache"
FIG = MATERIALS / "figures"

VALIDATION_DECISION = "20200123"
FINAL_DECISION = "20230131"
BASE_COLUMNS = ["ep_neutral_z", "ln_mv", "float_ratio"]
CONTINUOUS_NAMES = [
    "EP", "LogSize", "FloatRatio", "EP_squared", "LogSize_squared",
    "FloatRatio_squared", "EP_x_LogSize", "EP_x_FloatRatio", "LogSize_x_FloatRatio",
]
RIDGE_LAMBDAS = np.logspace(-6, 0, 19)
K_GRID = [1, 5, 20, 50, 100, 250, 500]
WEIGHTS = ["uniform", "distance"]
TREE_DEPTHS = [2, 3, 5, 8, None]
TREE_LEAFS = [0.002, 0.01, 0.05]
TREE_ALPHAS = [0.0, 1e-7, 1e-6, 1e-5, 1e-4]
DISPLAY_MONTHS = ["202301", "202401", "202501", "202512"]
EPS = 1e-12
KMAX = 500
QUERY_BATCH = 128


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def finite_num(x):
    if x is None:
        return None
    if isinstance(x, (np.floating, np.integer)):
        x = x.item()
    if isinstance(x, float) and (math.isnan(x) or math.isinf(x)):
        return None
    if isinstance(x, (float, int)):
        return float(x)
    return x


def design_raw(frame: pd.DataFrame, state: dict) -> np.ndarray:
    a = frame[BASE_COLUMNS].to_numpy(dtype=float).copy()
    for j in (1, 2):
        a[:, j] = np.clip(a[:, j], state["clip_low"][j], state["clip_high"][j])
    z = (a - np.array(state["base_mean"])) / np.array(state["base_scale"])
    continuous = np.column_stack([
        z, z[:, 0] ** 2, z[:, 1] ** 2, z[:, 2] ** 2,
        z[:, 0] * z[:, 1], z[:, 0] * z[:, 2], z[:, 1] * z[:, 2],
    ])
    industry = frame.l1_code.astype(str).to_numpy()
    dummies = np.column_stack([industry == level for level in state["industry_levels"][1:]]).astype(float)
    return np.column_stack([continuous, dummies])


def fit_preprocessing(frame: pd.DataFrame) -> dict:
    a = frame[BASE_COLUMNS].to_numpy(dtype=float).copy()
    low, high = [None, None, None], [None, None, None]
    for j in (1, 2):
        low[j], high[j] = np.quantile(a[:, j], [0.01, 0.99]).tolist()
        a[:, j] = np.clip(a[:, j], low[j], high[j])
    levels = sorted(frame.l1_code.astype(str).unique().tolist())
    state = {
        "clip_low": low, "clip_high": high, "base_columns": BASE_COLUMNS,
        "base_mean": a.mean(axis=0).tolist(), "base_scale": a.std(axis=0, ddof=0).tolist(),
        "industry_levels": levels, "reference_industry": levels[0],
        "fit_rows": int(len(frame)), "fit_first_month": str(frame.ym.min()),
        "fit_last_month": str(frame.ym.max()),
    }
    raw = design_raw(frame, state)
    names = CONTINUOUS_NAMES + [f"Industry_{v}" for v in levels[1:]]
    state["feature_names"] = names
    state["design_mean"] = raw.mean(axis=0).tolist()
    scale = raw.std(axis=0, ddof=0)
    if np.any(scale <= 0):
        raise RuntimeError("训练期出现常数设计列")
    state["design_scale"] = scale.tolist()
    return state


def transform(frame: pd.DataFrame, state: dict) -> np.ndarray:
    return (design_raw(frame, state) - np.array(state["design_mean"])) / np.array(state["design_scale"])


def mse(y, p):
    keep = np.isfinite(y) & np.isfinite(p)
    return float(np.mean((y[keep] - p[keep]) ** 2)) if keep.any() else None


def mae(y, p):
    keep = np.isfinite(y) & np.isfinite(p)
    return float(np.mean(np.abs(y[keep] - p[keep]))) if keep.any() else None


def pearson(x, y, ranked=False):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    keep = np.isfinite(x) & np.isfinite(y)
    x, y = x[keep], y[keep]
    if len(x) < 3 or np.ptp(x) <= 1e-12 or np.ptp(y) <= 1e-12:
        return None
    if ranked:
        x = pd.Series(x).rank(method="average").to_numpy()
        y = pd.Series(y).rank(method="average").to_numpy()
    c = np.corrcoef(x, y)[0, 1]
    return finite_num(c)


def fit_ols(X, y):
    n = X.shape[0]
    Z = np.column_stack([np.ones(n), X])
    coef, *_ = np.linalg.lstsq(Z, y, rcond=None)
    return float(coef[0]), coef[1:]


def fit_ridge(X, y, lam):
    y_mean = float(y.mean())
    x_mean = X.mean(axis=0)
    yc, Xc = y - y_mean, X - x_mean
    n, p = X.shape
    A = (Xc.T @ Xc) / n + lam * np.eye(p)
    beta = np.linalg.solve(A, (Xc.T @ yc) / n)
    return y_mean - float(x_mean @ beta), beta


def predict_linear(intercept, beta, X):
    return intercept + X @ beta


def metrics(pred, y, months, benchmark, constant=False, ranking_only=False):
    keep = np.isfinite(pred) & np.isfinite(y)
    values = {
        "n_predict": int(np.isfinite(pred).sum()),
        "n_evaluable": int(keep.sum()),
        "n_months": int(pd.Series(months).nunique()),
        "mse": None, "rmse": None, "mae": None, "r2_frozen_mean": None,
        "mean_ic": None, "mean_rank_ic": None, "n_ic_months": 0, "n_rank_ic_months": 0,
    }
    if ranking_only:
        pass
    elif keep.any():
        m = mse(y, pred)
        values["mse"] = m
        values["rmse"] = float(np.sqrt(m))
        values["mae"] = mae(y, pred)
        sse_b = float(np.sum((y[keep] - benchmark) ** 2))
        if sse_b > EPS:
            values["r2_frozen_mean"] = float(1 - np.sum((y[keep] - pred[keep]) ** 2) / sse_b)
    if not constant and not ranking_only:
        ic_list, ric_list = [], []
        for month in sorted(pd.unique(months)):
            at = months == month
            ic, ric = pearson(pred[at], y[at]), pearson(pred[at], y[at], ranked=True)
            if ic is not None:
                ic_list.append(ic)
            if ric is not None:
                ric_list.append(ric)
        if ic_list:
            values["mean_ic"] = float(np.mean(ic_list))
            values["n_ic_months"] = len(ic_list)
        if ric_list:
            values["mean_rank_ic"] = float(np.mean(ric_list))
            values["n_rank_ic_months"] = len(ric_list)
    return values


def monthly_rows(pred, y, months, model, stage):
    rows = []
    for month in sorted(pd.unique(months)):
        at = months == month
        keep = np.isfinite(pred[at]) & np.isfinite(y[at])
        rows.append({
            "model": model, "stage": stage, "ym": str(month),
            "n_predict": int(at.sum()), "n_evaluable": int(keep.sum()),
            "mse": mse(y[at], pred[at]) if keep.any() else None,
            "ic": pearson(pred[at], y[at]),
            "rank_ic": pearson(pred[at], y[at], ranked=True),
        })
    return rows


def close_best(mse_map, prefer):
    valid = {k: v for k, v in mse_map.items() if v is not None and np.isfinite(v)}
    best = min(valid.values())
    pool = [k for k, v in valid.items() if v <= best + max(1e-12, 1e-10 * abs(best))]
    return prefer(pool), best, pool


def knn_id(k, w):
    return f"KNN:k={k:03d}:weights={w}"


def tree_id(depth, leaf, alpha):
    d = "None" if depth is None else str(depth)
    a = "0" if alpha == 0 else format(alpha, ".0e")
    return f"Tree:depth={d}:leaf={leaf:.3f}:alpha={a}"


def knn_from_neighbors(y_nb, d2_nb, k, weights):
    yk, d2 = y_nb[:, :k], np.maximum(d2_nb[:, :k], 0.0)
    d = np.sqrt(d2)
    if weights == "uniform":
        w = np.ones_like(d)
    else:
        zero = d <= 1e-12
        w = np.zeros_like(d)
        any_zero = zero.any(axis=1)
        w[zero] = 1.0
        inv = np.divide(1.0, d, out=np.zeros_like(d), where=~zero)
        w[~any_zero] = inv[~any_zero]
    wsum = w.sum(axis=1, keepdims=True)
    w = np.divide(w, wsum, out=np.zeros_like(w), where=wsum > 0)
    pred = (w * yk).sum(axis=1)
    pred[wsum[:, 0] <= 0] = np.nan
    return pred


def _knn_paths(stem: Path):
    return stem.with_name(stem.name + "-idx.npy"), stem.with_name(stem.name + "-d2.npy"), stem.with_name(stem.name + "-meta.json")


def search_neighbors(X_train, y_train, keys_train, X_query, stem: Path, kmax=KMAX, batch=QUERY_BATCH):
    n_q = X_query.shape[0]
    idx_path, d2_path, meta_path = _knn_paths(stem)
    start_at = 0
    elapsed0 = 0.0
    if idx_path.exists() and d2_path.exists() and meta_path.exists():
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        if meta.get("n_query") == n_q and meta.get("kmax") == kmax:
            start_at = int(meta.get("done", 0))
            elapsed0 = float(meta.get("sec", 0.0))
            if start_at >= n_q:
                print(f"  reuse {stem.name} ({n_q} queries)", flush=True)
                return np.load(idx_path, mmap_mode="r"), np.load(d2_path, mmap_mode="r"), elapsed0
            print(f"  resume {stem.name} from {start_at}/{n_q}", flush=True)
            idx = np.lib.format.open_memmap(idx_path, mode="r+", dtype=np.int32, shape=(n_q, kmax))
            d2s = np.lib.format.open_memmap(d2_path, mode="r+", dtype=np.float64, shape=(n_q, kmax))
        else:
            start_at = 0
    if start_at == 0:
        idx = np.lib.format.open_memmap(idx_path, mode="w+", dtype=np.int32, shape=(n_q, kmax))
        d2s = np.lib.format.open_memmap(d2_path, mode="w+", dtype=np.float64, shape=(n_q, kmax))
    t2 = np.sum(X_train * X_train, axis=1)
    start = time.time()
    for lo in range(start_at, n_q, batch):
        hi = min(n_q, lo + batch)
        Q = X_query[lo:hi]
        q2 = np.sum(Q * Q, axis=1)
        d2 = q2[:, None] + t2[None, :] - 2.0 * (Q @ X_train.T)
        np.maximum(d2, 0.0, out=d2)
        for i in range(d2.shape[0]):
            row = d2[i]
            cutoff = row[np.argpartition(row, kmax - 1)[kmax - 1]]
            cand = np.flatnonzero(row <= cutoff)
            order = cand[np.lexsort((keys_train[cand], row[cand]))][:kmax]
            idx[lo + i] = order
            d2s[lo + i] = row[order]
        if hi == n_q or (lo // batch) % 20 == 0:
            idx.flush()
            d2s.flush()
            dump({"n_query": n_q, "kmax": kmax, "done": hi, "sec": elapsed0 + time.time() - start}, meta_path)
            print(f"  knn queries {hi}/{n_q} elapsed={elapsed0 + time.time()-start:.1f}s", flush=True)
    sec = elapsed0 + time.time() - start
    dump({"n_query": n_q, "kmax": kmax, "done": n_q, "sec": sec}, meta_path)
    return idx, d2s, sec


def load_or_search(stem: Path, X_train, y_train, keys_train, X_query, label: str):
    print(f"{label}...", flush=True)
    return search_neighbors(X_train, y_train, keys_train, X_query, stem)


def confusion_at(y, p, thr):
    pred = (p >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    prec = precision_score(y, pred, zero_division=np.nan)
    rec = recall_score(y, pred, zero_division=np.nan)
    spec = tn / (tn + fp) if (tn + fp) else np.nan
    f1 = f1_score(y, pred, zero_division=np.nan)
    return {
        "threshold": thr, "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
        "accuracy": float((tn + tp) / len(y)),
        "precision": finite_num(prec), "recall": finite_num(rec),
        "specificity": finite_num(spec), "f1": finite_num(f1),
        "contact_rate": float(pred.mean()),
    }


def dump(obj, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def run_bank():
    df = pd.read_csv(DATA / "bank-additional.csv", sep=";")
    assert len(df) == 4119
    y = (df["y"] == "yes").astype(int).to_numpy()
    X = df.drop(columns=["duration", "y"]).copy()
    cat = X.select_dtypes(include="object").columns.tolist()
    num = [c for c in X.columns if c not in cat]
    idx = np.arange(len(df))
    dev_idx, test_idx = train_test_split(idx, test_size=1000, stratify=y, random_state=1)
    train_idx, val_idx = train_test_split(dev_idx, test_size=624, stratify=y[dev_idx], random_state=2)
    pre = ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), cat),
        ("num", "passthrough", num),
    ])
    Xt = pre.fit_transform(X.iloc[train_idx])
    Xv = pre.transform(X.iloc[val_idx])
    Xd = pre.fit_transform(X.iloc[dev_idx])  # refit later; keep encoder object per stage
    # re-fit train encoder for candidates
    pre_train = ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), cat),
        ("num", "passthrough", num),
    ])
    X_train = pre_train.fit_transform(X.iloc[train_idx])
    X_val = pre_train.transform(X.iloc[val_idx])
    y_train, y_val, y_test = y[train_idx], y[val_idx], y[test_idx]
    n = len(train_idx)
    grid = []
    best = None
    for crit, depth, leaf, alpha in product(["gini", "entropy"], [2, 3, 5, None], [0.01, 0.05], [0.0, 1e-4, 1e-3, 1e-2]):
        min_leaf = int(np.ceil(leaf * n))
        clf = DecisionTreeClassifier(
            criterion=crit, max_depth=depth, min_samples_leaf=min_leaf,
            min_samples_split=max(2, 2 * min_leaf), ccp_alpha=alpha,
            random_state=123, splitter="best", max_features=None,
        )
        clf.fit(X_train, y_train)
        yes_col = list(clf.classes_).index(1)
        pv = clf.predict_proba(X_val)[:, yes_col]
        brier = float(np.mean((pv - y_val) ** 2))
        cid = f"BankTree:criterion={crit}:depth={'None' if depth is None else depth}:leaf={leaf:.3f}:alpha={'0' if alpha==0 else format(alpha,'.0e')}"
        rec = {"candidate_id": cid, "criterion": crit, "max_depth": depth, "leaf": leaf, "alpha": alpha,
               "n_leaves": int(clf.get_n_leaves()), "brier": brier}
        grid.append(rec)
        if best is None or brier < best["brier"] - 1e-12:
            best = rec | {"model": clf, "yes_col": yes_col}
    # freeze on 3119 development rows
    pre_final = ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), cat),
        ("num", "passthrough", num),
    ])
    X_dev = pre_final.fit_transform(X.iloc[dev_idx])
    X_test = pre_final.transform(X.iloc[test_idx])
    min_leaf = int(np.ceil(best["leaf"] * len(dev_idx)))
    final = DecisionTreeClassifier(
        criterion=best["criterion"], max_depth=best["max_depth"],
        min_samples_leaf=min_leaf, min_samples_split=max(2, 2 * min_leaf),
        ccp_alpha=best["alpha"], random_state=123, splitter="best",
    ).fit(X_dev, y[dev_idx])
    yes_col = list(final.classes_).index(1)
    p_val = best["model"].predict_proba(X_val)[:, best["yes_col"]]
    p_test = final.predict_proba(X_test)[:, yes_col]
    out = {
        "n_rows": 4119, "yes": int(y.sum()), "no": int((1 - y).sum()),
        "n_train": int(len(train_idx)), "n_val": int(len(val_idx)), "n_test": int(len(test_idx)),
        "dropped": ["duration"],
        "selected": {k: best[k] for k in ["candidate_id", "criterion", "max_depth", "leaf", "alpha", "n_leaves", "brier"]},
        "validation": {
            "brier": float(brier_score_loss(y_val, p_val)),
            "auc": float(roc_auc_score(y_val, p_val)),
            "ap": float(average_precision_score(y_val, p_val)),
            "thr_0.5": confusion_at(y_val, p_val, 0.5),
            "thr_0.1": confusion_at(y_val, p_val, 0.1),
            "prob_yes": p_val.tolist(),
            "y": y_val.astype(int).tolist(),
        },
        "test": {
            "brier": float(brier_score_loss(y_test, p_test)),
            "auc": float(roc_auc_score(y_test, p_test)),
            "ap": float(average_precision_score(y_test, p_test)),
            "thr_0.5": confusion_at(y_test, p_test, 0.5),
            "thr_0.1": confusion_at(y_test, p_test, 0.1),
        },
        "importances": sorted(
            [{"feature": n, "mdi": float(v)} for n, v in zip(pre_final.get_feature_names_out(), final.feature_importances_)],
            key=lambda r: -r["mdi"],
        )[:12],
        "grid_head": sorted(grid, key=lambda r: r["brier"])[:8],
    }
    dump(out, OUT / "bank-classification.json")
    pd.DataFrame(grid).to_csv(OUT / "bank-grid.csv", index=False)
    return out


def main():
    t0 = time.time()
    OUT.mkdir(parents=True, exist_ok=True)
    CHECKS.mkdir(parents=True, exist_ok=True)
    CACHE.mkdir(parents=True, exist_ok=True)
    panel = DATA / "ep_ml_panel.parquet"
    print("bank...", flush=True)
    bank = run_bank()
    print("bank selected", bank["selected"]["candidate_id"], "val brier", bank["selected"]["brier"], flush=True)

    sha = sha256_file(panel)
    df = pd.read_parquet(panel)
    df["float_ratio"] = df.circ_mv / df.total_mv
    df["row_key"] = df.ym.astype(str) + "|" + df.ts_code.astype(str)
    df["feature_ok"] = (
        np.isfinite(df.ep_neutral_z) & np.isfinite(df.ln_mv) & np.isfinite(df.float_ratio)
        & df.l1_code.notna() & (df.total_mv > 0) & (df.circ_mv > 0)
    )
    df["label_ok"] = np.isfinite(df.ret_open_1m)
    init = df[(df.split == "research") & (df.t_exit < VALIDATION_DECISION) & df.feature_ok & df.label_ok].copy()
    val_feat = df[(df.split == "validation") & (df.t_exit < FINAL_DECISION) & df.feature_ok].copy()
    val_eval_mask = val_feat.label_ok.to_numpy()
    final = df[((df.split == "research") | (df.split == "validation")) & (df.t_exit < FINAL_DECISION) & df.feature_ok & df.label_ok].copy()
    test_feat = df[(df.split == "test") & df.feature_ok].copy()
    test_eval_mask = test_feat.label_ok.to_numpy()
    print("samples", len(init), len(val_feat), int(val_eval_mask.sum()), len(final), len(test_feat), int(test_eval_mask.sum()), flush=True)

    st_init = fit_preprocessing(init)
    st_final = fit_preprocessing(final)
    X_init, y_init = transform(init, st_init), init.ret_open_1m.to_numpy(dtype=float)
    X_val = transform(val_feat, st_init)
    y_val = val_feat.ret_open_1m.to_numpy(dtype=float)
    X_final, y_final = transform(final, st_final), final.ret_open_1m.to_numpy(dtype=float)
    X_test = transform(test_feat, st_final)
    y_test = test_feat.ret_open_1m.to_numpy(dtype=float)
    months_val = val_feat.ym.to_numpy()
    months_test = test_feat.ym.to_numpy()
    mean_init, mean_final = float(y_init.mean()), float(y_final.mean())

    # linear baselines
    ols_i, ols_b = fit_ols(X_init, y_init)
    p_val_ols = predict_linear(ols_i, ols_b, X_val)
    ridge_map = {}
    for lam in RIDGE_LAMBDAS:
        ri, rb = fit_ridge(X_init, y_init, float(lam))
        ridge_map[float(lam)] = mse(y_val[val_eval_mask], predict_linear(ri, rb, X_val)[val_eval_mask])
    lam_star, _, _ = close_best(ridge_map, lambda pool: max(pool))
    ri, rb = fit_ridge(X_init, y_init, lam_star)
    p_val_ridge = predict_linear(ri, rb, X_val)
    ep_i, ep_b = fit_ols(init.ep_neutral_z.to_numpy()[:, None], y_init)
    p_val_ep = ep_i + ep_b[0] * val_feat.ep_neutral_z.to_numpy()
    p_val_mean = np.full(len(val_feat), mean_init)

    # trees
    print("trees...", flush=True)
    tree_grid = []
    best_tree = None
    n = len(init)
    for depth, leaf, alpha in product(TREE_DEPTHS, TREE_LEAFS, TREE_ALPHAS):
        min_leaf = int(np.ceil(leaf * n))
        model = DecisionTreeRegressor(
            criterion="squared_error", splitter="best", max_features=None, random_state=42,
            max_depth=depth, min_samples_leaf=min_leaf, min_samples_split=max(2, 2 * min_leaf),
            ccp_alpha=alpha,
        )
        model.fit(X_init, y_init)
        pred = model.predict(X_val)
        m = mse(y_val[val_eval_mask], pred[val_eval_mask])
        rec = {
            "candidate_id": tree_id(depth, leaf, alpha),
            "max_depth": depth, "min_leaf_fraction": leaf, "ccp_alpha": alpha,
            "min_samples_leaf": min_leaf, "n_leaves": int(model.get_n_leaves()),
            "max_depth_actual": int(model.get_depth()), "val_mse": m,
        }
        tree_grid.append(rec)
        if best_tree is None or m < best_tree["val_mse"] - 1e-12:
            best_tree = rec | {"model": model}
    def tree_tie(pool, grid=tree_grid):
        lookup = {r["candidate_id"]: r for r in grid}
        ranked = sorted(pool, key=lambda cid: (
            lookup[cid]["n_leaves"], lookup[cid]["max_depth_actual"],
            -lookup[cid]["ccp_alpha"], -lookup[cid]["min_leaf_fraction"],
            99 if lookup[cid]["max_depth"] is None else lookup[cid]["max_depth"], cid,
        ))
        return ranked[0]
    tree_mse_map = {r["candidate_id"]: r["val_mse"] for r in tree_grid}
    tree_sel, tree_best_mse, _ = close_best(tree_mse_map, tree_tie)
    best_tree = next(r for r in tree_grid if r["candidate_id"] == tree_sel)
    print("selected tree", tree_sel, tree_best_mse, flush=True)

    min_leaf_f = int(np.ceil(best_tree["min_leaf_fraction"] * len(final)))
    tree_final = DecisionTreeRegressor(
        criterion="squared_error", splitter="best", max_features=None, random_state=42,
        max_depth=best_tree["max_depth"], min_samples_leaf=min_leaf_f,
        min_samples_split=max(2, 2 * min_leaf_f), ccp_alpha=best_tree["ccp_alpha"],
    ).fit(X_final, y_final)
    p_val_tree = next(r for r in tree_grid if r["candidate_id"] == tree_sel)
    # Fit the selected tree on the initial training sample for validation predictions.
    min_leaf_i = int(np.ceil(best_tree["min_leaf_fraction"] * n))
    tree_init = DecisionTreeRegressor(
        criterion="squared_error", splitter="best", max_features=None, random_state=42,
        max_depth=best_tree["max_depth"], min_samples_leaf=min_leaf_i,
        min_samples_split=max(2, 2 * min_leaf_i), ccp_alpha=best_tree["ccp_alpha"],
    ).fit(X_init, y_init)
    p_val_tree = tree_init.predict(X_val)

    # final linear
    ols_fi, ols_fb = fit_ols(X_final, y_final)
    ridge_fi, ridge_fb = fit_ridge(X_final, y_final, lam_star)
    ep_fi, ep_fb = fit_ols(final.ep_neutral_z.to_numpy()[:, None], y_final)
    preds_val = {
        "OLS": p_val_ols, "Ridge": p_val_ridge, "Tree": p_val_tree,
        "EP_OLS": p_val_ep, "FrozenMean": p_val_mean, "EP_score": val_feat.ep_neutral_z.to_numpy(),
    }
    preds_test = {
        "OLS": predict_linear(ols_fi, ols_fb, X_test),
        "Ridge": predict_linear(ridge_fi, ridge_fb, X_test),
        "Tree": tree_final.predict(X_test),
        "EP_OLS": ep_fi + ep_fb[0] * test_feat.ep_neutral_z.to_numpy(),
        "FrozenMean": np.full(len(test_feat), mean_final),
        "EP_score": test_feat.ep_neutral_z.to_numpy(),
    }

    # KNN
    keys_init = np.array(init.row_key.to_numpy())
    key_rank = pd.Series(keys_init).rank(method="first").to_numpy()
    val_idx, val_d2, knn_val_sec = load_or_search(
        CACHE / "knn-val-neighbors", X_init, y_init, key_rank, X_val, "knn validation search"
    )
    y_nb = y_init[val_idx]
    knn_grid = []
    knn_val_pred = {}
    for k, w in product(K_GRID, WEIGHTS):
        pred = knn_from_neighbors(y_nb, val_d2, k, w)
        m = mse(y_val[val_eval_mask], pred[val_eval_mask])
        rec = {"candidate_id": knn_id(k, w), "k": k, "weights": w, "val_mse": m}
        knn_grid.append(rec)
        knn_val_pred[rec["candidate_id"]] = pred
        print(" ", rec["candidate_id"], m, flush=True)

    def knn_tie(pool):
        lookup = {r["candidate_id"]: r for r in knn_grid}
        return sorted(pool, key=lambda cid: (-lookup[cid]["k"], 0 if lookup[cid]["weights"] == "uniform" else 1, cid))[0]
    knn_sel, knn_best, _ = close_best({r["candidate_id"]: r["val_mse"] for r in knn_grid}, knn_tie)
    knn_chosen = next(r for r in knn_grid if r["candidate_id"] == knn_sel)
    print("selected knn", knn_sel, knn_best, flush=True)
    preds_val["KNN"] = knn_val_pred[knn_sel]

    key_rank_f = pd.Series(final.row_key.to_numpy()).rank(method="first").to_numpy()
    test_idx, test_d2, knn_test_sec = load_or_search(
        CACHE / "knn-test-neighbors", X_final, y_final, key_rank_f, X_test, "knn test search"
    )
    preds_test["KNN"] = knn_from_neighbors(y_final[test_idx], test_d2, knn_chosen["k"], knn_chosen["weights"])

    # examples
    example_rows = []
    for ym in DISPLAY_MONTHS:
        sub = test_feat[test_feat.ym.astype(str) == ym]
        if sub.empty:
            continue
        loc = np.where(test_feat.ym.astype(str).to_numpy() == ym)[0]
        take = loc[:3]
        for j in take:
            row = test_feat.iloc[j]
            k = knn_chosen["k"]
            nb_i = test_idx[j, :k]
            d2 = test_d2[j, :k]
            yy = y_final[nb_i]
            pred_one = preds_test["KNN"][j]
            neighbors = []
            wpred = knn_from_neighbors(yy[None, :], d2[None, :], k, knn_chosen["weights"])[0]
            # reconstruct weights
            d = np.sqrt(np.maximum(d2, 0))
            if knn_chosen["weights"] == "uniform":
                w = np.ones(k) / k
            else:
                zero = d <= 1e-12
                if zero.any():
                    w = zero.astype(float)
                    w /= w.sum()
                else:
                    w = 1.0 / d
                    w /= w.sum()
            for t, wi in enumerate(w):
                rec_nb = final.iloc[int(nb_i[t])]
                neighbors.append({
                    "row_key": rec_nb.row_key, "ts_code": rec_nb.ts_code, "name": rec_nb["name"],
                    "ym": str(rec_nb.ym), "y": finite_num(rec_nb.ret_open_1m),
                    "distance": finite_num(float(np.sqrt(max(d2[t], 0)))),
                    "weight": finite_num(float(wi)),
                    "contribution": finite_num(float(wi * rec_nb.ret_open_1m)),
                })
            # tree path
            node = 0
            tree = tree_final.tree_
            path = []
            xrow = X_test[j]
            while tree.children_left[node] != -1:
                feat = int(tree.feature[node])
                thr = float(tree.threshold[node])
                val = float(xrow[feat])
                left = val <= thr
                path.append({
                    "feature": st_final["feature_names"][feat],
                    "threshold": thr, "value": val,
                    "direction": "left" if left else "right",
                    "n": int(tree.n_node_samples[node]),
                })
                node = int(tree.children_left[node] if left else tree.children_right[node])
            example_rows.append({
                "row_key": row.row_key, "ts_code": row.ts_code, "name": row["name"], "ym": str(row.ym),
                "y": finite_num(row.ret_open_1m),
                "pred_knn": finite_num(pred_one),
                "pred_tree": finite_num(preds_test["Tree"][j]),
                "pred_ols": finite_num(preds_test["OLS"][j]),
                "leaf_n": int(tree.n_node_samples[node]),
                "leaf_mean": finite_num(float(tree.value[node, 0, 0])),
                "neighbors": neighbors,
                "tree_path": path,
            })

    model_rows, month_rows = [], []
    for stage, preds, y, months, mask, bench in (
        ("validation", preds_val, y_val, months_val, val_eval_mask, mean_init),
        ("teaching_test", preds_test, y_test, months_test, test_eval_mask, mean_final),
    ):
        for name, pred in preds.items():
            ranking = name == "EP_score"
            constant = name == "FrozenMean"
            met = metrics(pred, y, months, bench, constant=constant, ranking_only=ranking)
            model_rows.append({"model": name, "stage": stage, **met})
            month_rows.extend(monthly_rows(pred, y, months, name, stage))

    pd.DataFrame(tree_grid).to_csv(OUT / "tree-grid.csv", index=False)
    pd.DataFrame(knn_grid).to_csv(OUT / "knn-grid.csv", index=False)
    pd.DataFrame(model_rows).to_csv(OUT / "stock-model-metrics.csv", index=False)
    pd.DataFrame(month_rows).to_csv(OUT / "stock-monthly-metrics.csv", index=False)
    dump(example_rows, OUT / "examples.json")

    mdi = tree_final.feature_importances_
    names = st_final["feature_names"]
    groups = {"base": names[:3], "square": names[3:6], "interact": names[6:9], "industry": names[9:]}
    grouped = {g: float(sum(mdi[names.index(c)] for c in cols)) for g, cols in groups.items()}
    top_mdi = sorted([{"feature": n, "mdi": float(v)} for n, v in zip(names, mdi)], key=lambda r: -r["mdi"])[:12]

    payload = {
        "schema_version": "ml3-1.0",
        "status": "computed",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "input_sha256": sha,
        "sample_summary": {
            "source_rows": int(len(df)),
            "initial_train": int(len(init)),
            "validation_predict": int(len(val_feat)),
            "validation_eval": int(val_eval_mask.sum()),
            "final_refit": int(len(final)),
            "teaching_test_predict": int(len(test_feat)),
            "teaching_test_eval": int(test_eval_mask.sum()),
            "design_columns": 36,
        },
        "selection": {
            "knn": knn_chosen,
            "tree": {k: best_tree[k] for k in best_tree if k != "model"},
            "ridge_lambda": float(lam_star),
        },
        "metrics": model_rows,
        "monthly": [r for r in month_rows if r["stage"] == "teaching_test"],
        "mdi_top": top_mdi,
        "mdi_grouped": grouped,
        "examples": example_rows,
        "bank": {
            "selected": bank["selected"],
            "validation": {k: bank["validation"][k] for k in bank["validation"] if k not in {"prob_yes", "y"}},
            "test": bank["test"],
            "importances": bank["importances"],
        },
        "runtime": {
            "knn_val_sec": knn_val_sec, "knn_test_sec": knn_test_sec,
            "total_sec": time.time() - t0,
        },
    }
    dump(payload, OUT / "interaction-data.json")
    dump({"input_sha256": sha, "passed": True, "n_init": len(init), "n_val_eval": int(val_eval_mask.sum())},
         CHECKS / "validation-checks.json")
    try:
        draw_app_figures(payload, month_rows, knn_grid, tree_grid)
    except Exception as exc:
        print("app figures failed:", exc, flush=True)
        raise
    print("done in", time.time() - t0, "s", flush=True)


def draw_app_figures(payload, month_rows, knn_grid, tree_grid):
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates

    CREAM, INK, GOLD, TEAL, RED, MUTED, BODY = "#FDF8E8", "#3E2028", "#D4B48C", "#35665F", "#974F4E", "#76675D", "#4A4440"
    SURFACE, BORDER, WARM = "#E6DBC6", "#C9BEAE", "#8B5E3C"
    mpl.rcParams.update({
        "font.sans-serif": ["PingFang SC", "Heiti SC", "STHeiti", "Songti SC", "Arial Unicode MS"],
        "font.family": "sans-serif", "axes.unicode_minus": False,
        "figure.facecolor": CREAM, "axes.facecolor": CREAM, "savefig.facecolor": CREAM,
    })

    def style(ax, title):
        ax.set_title(title, loc="left", color=INK, fontweight=600)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.grid(True, color=SURFACE, lw=0.8)
        ax.set_axisbelow(True)

    def save(fig, name):
        FIG.mkdir(parents=True, exist_ok=True)
        p = FIG / name
        fig.savefig(p, dpi=200, facecolor=CREAM)
        plt.close(fig)
        print("app fig", name)

    test = [r for r in payload["metrics"] if r["stage"] == "teaching_test"]
    order = ["FrozenMean", "EP_OLS", "OLS", "Ridge", "KNN", "Tree"]
    test_map = {r["model"]: r for r in test}
    fig, axes = plt.subplots(1, 2, figsize=(11.20, 4.20), dpi=200)
    fig.subplots_adjust(left=0.08, right=0.98, top=0.84, bottom=0.22, wspace=0.28)
    rmse = [test_map[m]["rmse"] for m in order]
    ric = [test_map[m]["mean_rank_ic"] if test_map[m]["mean_rank_ic"] is not None else np.nan for m in order]
    style(axes[0], "教学测试 RMSE（纵轴从 0 起）")
    axes[0].bar(order, rmse, color=[MUTED, WARM, INK, "#5B7C8A", TEAL, RED])
    axes[0].set_ylim(0, max(rmse) * 1.15)
    axes[0].tick_params(axis="x", rotation=20)
    style(axes[1], "教学测试平均 Rank IC")
    colors = [MUTED, WARM, INK, "#5B7C8A", TEAL, RED]
    axes[1].bar(order, ric, color=colors)
    axes[1].axhline(0, color=BORDER, lw=1)
    axes[1].tick_params(axis="x", rotation=20)
    save(fig, "fig-stock-compare.png")

    fig, ax = plt.subplots(figsize=(11.20, 4.20), dpi=200)
    fig.subplots_adjust(left=0.09, right=0.97, top=0.86, bottom=0.22)
    style(ax, "KNN 验证 MSE：K 与权重")
    for w, label, c, mk in (("uniform", "等权", TEAL, "o"), ("distance", "距离加权", WARM, "s")):
        sub = [r for r in knn_grid if r["weights"] == w]
        ax.plot([r["k"] for r in sub], [r["val_mse"] for r in sub], color=c, marker=mk, lw=2.2, label=label)
    ax.set_xscale("log")
    ax.set_xlabel("K")
    ax.set_ylabel("验证 MSE")
    ax.legend(frameon=False)
    save(fig, "fig-stock-knn-path.png")

    fig, ax = plt.subplots(figsize=(11.20, 4.20), dpi=200)
    fig.subplots_adjust(left=0.09, right=0.97, top=0.86, bottom=0.22)
    style(ax, "回归树 75 个候选的验证 MSE")
    xs = np.arange(len(tree_grid))
    ys = [r["val_mse"] for r in tree_grid]
    ax.scatter(xs, ys, s=18, c=TEAL, alpha=0.8)
    sel = payload["selection"]["tree"]["candidate_id"]
    for i, r in enumerate(tree_grid):
        if r["candidate_id"] == sel:
            ax.scatter([i], [r["val_mse"]], s=80, c=RED, zorder=3)
            ax.annotate("选中", (i, r["val_mse"]), color=RED, fontsize=11, xytext=(8, 8), textcoords="offset points")
    ax.set_xlabel("候选序号")
    ax.set_ylabel("验证 MSE")
    save(fig, "fig-stock-tree-grid.png")

    fig, ax = plt.subplots(figsize=(11.20, 4.20), dpi=200)
    fig.subplots_adjust(left=0.09, right=0.97, top=0.86, bottom=0.22)
    style(ax, "教学测试逐月 Rank IC")
    test_months = pd.DataFrame(r for r in month_rows if r["stage"] == "teaching_test")
    test_months["date"] = pd.to_datetime(test_months["ym"].astype(str), format="%Y%m")
    test_months = test_months.sort_values("date")
    for model, c in (("KNN", TEAL), ("Tree", RED), ("OLS", INK), ("EP_OLS", WARM)):
        sub = test_months.loc[test_months["model"] == model]
        ax.plot(sub["date"], sub["rank_ic"], color=c, lw=1.6, label=model)
    ax.axhline(0, color=BORDER, lw=1)
    ticks = test_months.loc[test_months["date"].dt.month.isin([1, 7]), "date"].drop_duplicates()
    ax.set_xticks(ticks)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m"))
    ax.tick_params(axis="x", rotation=45, labelsize=9)
    ax.legend(frameon=False, ncol=4, loc="lower right", bbox_to_anchor=(1, 1))
    save(fig, "fig-monthly-rankic.png")

    fig, ax = plt.subplots(figsize=(11.20, 4.20), dpi=200)
    fig.subplots_adjust(left=0.22, right=0.97, top=0.86, bottom=0.16)
    style(ax, "最终回归树的分裂重要性（前 10 列）")
    top = payload["mdi_top"][:10][::-1]
    ax.barh([r["feature"] for r in top], [r["mdi"] for r in top], color=TEAL)
    ax.set_xlabel("MDI")
    save(fig, "fig-stock-importance.png")

    ex = payload["examples"][0] if payload["examples"] else None
    if ex:
        fig, ax = plt.subplots(figsize=(11.20, 4.20), dpi=200)
        fig.subplots_adjust(left=0.10, right=0.97, top=0.84, bottom=0.28)
        style(ax, f"{ex['name']} {ex['ym']} 的 KNN 邻居贡献")
        show = ex["neighbors"][:20]
        rest = ex["neighbors"][20:]
        labels = [n["ts_code"] + " " + n["ym"] for n in show]
        contrib = [n["contribution"] for n in show]
        if rest:
            labels.append("其余合计")
            contrib.append(sum(n["contribution"] or 0 for n in rest))
        ax.bar(range(len(labels)), contrib, color=TEAL)
        ax.set_xticks(range(len(labels)))
        ax.set_xticklabels(labels, rotation=55, ha="right", fontsize=8)
        ax.axhline(0, color=BORDER, lw=1)
        ax.set_ylabel("权重 × 收益率 y")
        save(fig, "fig-stock-neighbors.png")


if __name__ == "__main__":
    main()
