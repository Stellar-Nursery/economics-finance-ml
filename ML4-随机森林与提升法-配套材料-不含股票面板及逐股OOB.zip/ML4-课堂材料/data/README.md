# ML4 数据说明

公开包保留教学汇总、图表和 12 条有限股票案例，不含以下逐股明细。补齐数据前可阅读 Notebook 的已有输出与交互网页。

| 文件及放置路径 | 内容 | 行数 |
| --- | --- | ---: |
| `ML4-课堂材料/data/ep_ml_panel.parquet` | 课程正盈利股票面板，供样本与信息时点核验及模型拟合 | 365,982 |
| `ML4-课堂材料/output/forest-oob.parquet` | 初次训练池逐条记录的随机森林袋外结果 | 125,747 |

向教师领取 `ML4-随机森林与提升法-课堂数据.zip`，解压后将 `ML4-课堂材料/` 内的 `data/` 和 `output/` 合并到公开包同名目录，再从第一个代码单元依次运行 Notebook 的全部 19 个单元。完整课堂包已包含这两份文件，无需再合并数据包。

股票面板来自第五讲，按 `data/source-manifest.json` 保留全部原始行。目标 `ret_open_1m` 为既定开盘持有期收益率，单位为小数；股票、行业代码及日期保留字符串。模型只使用规定时间内已成熟的标签，数据预处理规则见 Notebook 与 `scripts/compute_models.py`。

逐股 OOB 文件的字段为 `row_key`、`y`、`oob_n_trees` 和 `oob_pred`，依次表示股票月份键、实际收益、可用袋外树数和袋外预测。该文件含训练行的真实收益，属于课堂数据，不放入公开包。Notebook 从它复算覆盖率和误差；模型拟合脚本本身不生成此诊断文件。

固定文件 SHA-256：

- `ep_ml_panel.parquet`：`5c1ceab6f7322db11c97fd0a11e16f40054876df74333a9d7ea05a6e96ed18f9`
- `forest-oob.parquet`：`90f2034ecdfeba1ec81b8c64ac930edd33e34fbc8e3a4ac7c70974171b32166b`

Notebook 的模型汇总、逐月指标和有限案例可直接阅读。EP_score 只有排序分数，不报告收益 MSE；FrozenMean 的 Rank IC 未定义。已有教学测试结果不等于独立投资检验，组合绩效还需指定交易规则和成本。

[返回运行说明](../README.md)
