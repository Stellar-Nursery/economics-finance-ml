#!/usr/bin/env python3
"""Fit ML4 ensemble models on the fifth-lecture stock panel (full sample)."""
from __future__ import annotations

import hashlib
import json
import math
import time
from datetime import datetime, timezone
from itertools import product
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import (
    AdaBoostRegressor,
    GradientBoostingRegressor,
    RandomForestRegressor,
)
from sklearn.tree import DecisionTreeRegressor

try:
    from xgboost import XGBRegressor
except Exception:  # pragma: no cover
    XGBRegressor = None
try:
    from lightgbm import LGBMRegressor
except Exception:  # pragma: no cover
    LGBMRegressor = None

_SCRIPT = Path(__file__).resolve()
if _SCRIPT.parent.name == "scripts":
    MATERIALS = _SCRIPT.parent.parent
else:
    TASK = _SCRIPT.parent
    ROOT = TASK.parent.parent
    LECTURE = ROOT / "课程课件/ML4-随机森林与提升法"
    MATERIALS = LECTURE / "配套材料/ML4-课堂材料"
DATA = MATERIALS / "data"
OUT = MATERIALS / "output"
CHECKS = MATERIALS / "checks"

VALIDATION_DECISION = "20200123"
FINAL_DECISION = "20230131"
BASE_COLUMNS = ["ep_neutral_z", "ln_mv", "float_ratio"]
CONTINUOUS_NAMES = [
    "EP", "LogSize", "FloatRatio", "EP_squared", "LogSize_squared",
    "FloatRatio_squared", "EP_x_LogSize", "EP_x_FloatRatio", "LogSize_x_FloatRatio",
]
RIDGE_LAMBDAS = np.logspace(-6, 0, 19)
TREE_DEPTHS = [2, 3, 5, 8, None]
TREE_LEAFS = [0.002, 0.01, 0.05]
TREE_ALPHAS = [0.0, 1e-7, 1e-6, 1e-5, 1e-4]
DISPLAY_MONTHS = ["202301", "202401", "202501", "202512"]
EPS = 1e-12
N_JOBS = 4


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def finite_num(x):
    if x is None:
        return None
    if isinstance(x, (np.floating, np.integer)):
        x = x.item()
    if isinstance(x, float) and (math.isnan(x) or math.isinf(x)):
        return None
    if isinstance(x, (float, int)):
        return float(x)
    return x


def dump(obj, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def design_raw(frame: pd.DataFrame, state: dict) -> np.ndarray:
    a = frame[BASE_COLUMNS].to_numpy(dtype=float).copy()
    for j in (1, 2):
        a[:, j] = np.clip(a[:, j], state["clip_low"][j], state["clip_high"][j])
    z = (a - np.array(state["base_mean"])) / np.array(state["base_scale"])
    continuous = np.column_stack([
        z, z[:, 0] ** 2, z[:, 1] ** 2, z[:, 2] ** 2,
        z[:, 0] * z[:, 1], z[:, 0] * z[:, 2], z[:, 1] * z[:, 2],
    ])
    industry = frame.l1_code.astype(str).to_numpy()
    dummies = np.column_stack([industry == level for level in state["industry_levels"][1:]]).astype(float)
    return np.column_stack([continuous, dummies])


def fit_preprocessing(frame: pd.DataFrame) -> dict:
    a = frame[BASE_COLUMNS].to_numpy(dtype=float).copy()
    low, high = [None, None, None], [None, None, None]
    for j in (1, 2):
        low[j], high[j] = np.quantile(a[:, j], [0.01, 0.99]).tolist()
        a[:, j] = np.clip(a[:, j], low[j], high[j])
    levels = sorted(frame.l1_code.astype(str).unique().tolist())
    state = {
        "clip_low": low, "clip_high": high, "base_columns": BASE_COLUMNS,
        "base_mean": a.mean(axis=0).tolist(), "base_scale": a.std(axis=0, ddof=0).tolist(),
        "industry_levels": levels, "reference_industry": levels[0],
        "fit_rows": int(len(frame)),
    }
    raw = design_raw(frame, state)
    names = CONTINUOUS_NAMES + [f"Industry_{v}" for v in levels[1:]]
    state["feature_names"] = names
    state["design_mean"] = raw.mean(axis=0).tolist()
    scale = raw.std(axis=0, ddof=0)
    if np.any(scale <= 0):
        raise RuntimeError("训练期出现常数设计列")
    state["design_scale"] = scale.tolist()
    return state


def transform(frame: pd.DataFrame, state: dict) -> np.ndarray:
    return (design_raw(frame, state) - np.array(state["design_mean"])) / np.array(state["design_scale"])


def mse(y, p):
    keep = np.isfinite(y) & np.isfinite(p)
    return float(np.mean((y[keep] - p[keep]) ** 2)) if keep.any() else None


def mae(y, p):
    keep = np.isfinite(y) & np.isfinite(p)
    return float(np.mean(np.abs(y[keep] - p[keep]))) if keep.any() else None


def pearson(x, y, ranked=False):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    keep = np.isfinite(x) & np.isfinite(y)
    x, y = x[keep], y[keep]
    if len(x) < 3 or np.ptp(x) <= 1e-12 or np.ptp(y) <= 1e-12:
        return None
    if ranked:
        x = pd.Series(x).rank(method="average").to_numpy()
        y = pd.Series(y).rank(method="average").to_numpy()
    c = np.corrcoef(x, y)[0, 1]
    return finite_num(c)


def fit_ols(X, y):
    n = X.shape[0]
    Z = np.column_stack([np.ones(n), X])
    coef, *_ = np.linalg.lstsq(Z, y, rcond=None)
    return float(coef[0]), coef[1:]


def fit_ridge(X, y, lam):
    y_mean = float(y.mean())
    x_mean = X.mean(axis=0)
    yc, Xc = y - y_mean, X - x_mean
    n, p = X.shape
    A = (Xc.T @ Xc) / n + lam * np.eye(p)
    beta = np.linalg.solve(A, (Xc.T @ yc) / n)
    return y_mean - float(x_mean @ beta), beta


def predict_linear(intercept, beta, X):
    return intercept + X @ beta


def metrics(pred, y, months, benchmark, constant=False, ranking_only=False):
    keep = np.isfinite(pred) & np.isfinite(y)
    values = {
        "n_predict": int(np.isfinite(pred).sum()),
        "n_evaluable": int(keep.sum()),
        "n_months": int(pd.Series(months).nunique()),
        "mse": None, "rmse": None, "mae": None, "r2_frozen_mean": None,
        "mean_ic": None, "mean_rank_ic": None, "n_ic_months": 0, "n_rank_ic_months": 0,
    }
    if keep.any() and not ranking_only:
        m = mse(y, pred)
        values["mse"] = m
        values["rmse"] = float(np.sqrt(m)) if m is not None else None
        values["mae"] = mae(y, pred)
        sse_b = float(np.sum((y[keep] - benchmark) ** 2))
        if sse_b > EPS:
            values["r2_frozen_mean"] = float(1 - np.sum((y[keep] - pred[keep]) ** 2) / sse_b)
    if not constant:
        ic_list, ric_list = [], []
        for month in sorted(pd.unique(months)):
            at = months == month
            ic, ric = pearson(pred[at], y[at]), pearson(pred[at], y[at], ranked=True)
            if ic is not None:
                ic_list.append(ic)
            if ric is not None:
                ric_list.append(ric)
        if ic_list:
            values["mean_ic"] = float(np.mean(ic_list))
            values["n_ic_months"] = len(ic_list)
        if ric_list:
            values["mean_rank_ic"] = float(np.mean(ric_list))
            values["n_rank_ic_months"] = len(ric_list)
    return values


def monthly_rows(pred, y, months, model, stage):
    rows = []
    for month in sorted(pd.unique(months)):
        at = months == month
        keep = np.isfinite(pred[at]) & np.isfinite(y[at])
        rows.append({
            "model": model, "stage": stage, "ym": str(month),
            "n_predict": int(at.sum()), "n_evaluable": int(keep.sum()),
            "mse": mse(y[at], pred[at]) if model != "EP_score" else None,
            "ic": pearson(pred[at], y[at]),
            "rank_ic": pearson(pred[at], y[at], ranked=True),
        })
    return rows


def close_best(mse_map, prefer):
    valid = {k: v for k, v in mse_map.items() if v is not None and np.isfinite(v)}
    best = min(valid.values())
    pool = [k for k, v in valid.items() if v <= best + max(1e-12, 1e-10 * abs(best))]
    return prefer(pool), best, pool


def tree_id(depth, leaf, alpha):
    d = "None" if depth is None else str(depth)
    a = "0" if alpha == 0 else format(alpha, ".0e")
    return f"Tree:depth={d}:leaf={leaf:.3f}:alpha={a}"


def leaf_params(n, leaf_fraction):
    min_leaf = int(np.ceil(leaf_fraction * n))
    return min_leaf, max(2, 2 * min_leaf)


def rf_predict_prefix(model, X, B):
    acc = np.zeros(X.shape[0], dtype=float)
    for i, est in enumerate(model.estimators_[:B]):
        acc += est.predict(X)
    return acc / B


def main():
    t0 = time.time()
    OUT.mkdir(parents=True, exist_ok=True)
    CHECKS.mkdir(parents=True, exist_ok=True)
    dest = DATA / "ep_ml_panel.parquet"
    if _SCRIPT.parent.name != "scripts" and not dest.exists():
        DATA.mkdir(parents=True, exist_ok=True)
        source = LECTURE / "教师参考/Grok制作材料/data/ep_ml_panel.parquet"
        dest.write_bytes(source.read_bytes())
    sha = sha256_file(dest)
    print("input sha", sha, flush=True)

    df = pd.read_parquet(dest)
    df["float_ratio"] = df.circ_mv / df.total_mv
    df["row_key"] = df.ym.astype(str) + "|" + df.ts_code.astype(str)
    df["feature_ok"] = (
        np.isfinite(df.ep_neutral_z) & np.isfinite(df.ln_mv) & np.isfinite(df.float_ratio)
        & df.l1_code.notna() & (df.total_mv > 0) & (df.circ_mv > 0)
    )
    df["label_ok"] = np.isfinite(df.ret_open_1m)
    init = df[(df.split == "research") & (df.t_exit < VALIDATION_DECISION) & df.feature_ok & df.label_ok].copy()
    val_feat = df[(df.split == "validation") & (df.t_exit < FINAL_DECISION) & df.feature_ok].copy()
    val_eval_mask = val_feat.label_ok.to_numpy()
    final = df[((df.split == "research") | (df.split == "validation")) & (df.t_exit < FINAL_DECISION) & df.feature_ok & df.label_ok].copy()
    test_feat = df[(df.split == "test") & df.feature_ok].copy()
    test_eval_mask = test_feat.label_ok.to_numpy()
    print("samples", len(init), len(val_feat), int(val_eval_mask.sum()), len(final), len(test_feat), int(test_eval_mask.sum()), flush=True)

    st_init = fit_preprocessing(init)
    st_final = fit_preprocessing(final)
    X_init, y_init = transform(init, st_init), init.ret_open_1m.to_numpy(dtype=float)
    X_val = transform(val_feat, st_init)
    y_val = val_feat.ret_open_1m.to_numpy(dtype=float)
    X_final, y_final = transform(final, st_final), final.ret_open_1m.to_numpy(dtype=float)
    X_test = transform(test_feat, st_final)
    y_test = test_feat.ret_open_1m.to_numpy(dtype=float)
    months_val = val_feat.ym.to_numpy()
    months_test = test_feat.ym.to_numpy()
    mean_init, mean_final = float(y_init.mean()), float(y_final.mean())
    n_init, n_final = len(init), len(final)

    grid_rows = []
    fitted = {}

    print("linear...", flush=True)
    ols_i, ols_b = fit_ols(X_init, y_init)
    p_val = {"OLS": predict_linear(ols_i, ols_b, X_val)}
    ridge_map = {}
    ridge_fit = {}
    for lam in RIDGE_LAMBDAS:
        ri, rb = fit_ridge(X_init, y_init, float(lam))
        ridge_fit[float(lam)] = (ri, rb)
        ridge_map[float(lam)] = mse(y_val[val_eval_mask], predict_linear(ri, rb, X_val)[val_eval_mask])
        grid_rows.append({"model": "Ridge", "candidate_id": f"Ridge:lambda={lam:.6g}", "val_mse": ridge_map[float(lam)]})
    lam_star, _, _ = close_best(ridge_map, lambda pool: max(pool))
    p_val["Ridge"] = predict_linear(*ridge_fit[lam_star], X_val)
    ep_i, ep_b = fit_ols(init.ep_neutral_z.to_numpy()[:, None], y_init)
    p_val["EP_OLS"] = ep_i + ep_b[0] * val_feat.ep_neutral_z.to_numpy()
    p_val["FrozenMean"] = np.full(len(val_feat), mean_init)
    p_val["EP_score"] = val_feat.ep_neutral_z.to_numpy()
    print("ridge lambda", lam_star, flush=True)

    print("trees...", flush=True)
    tree_grid = []
    for depth, leaf, alpha in product(TREE_DEPTHS, TREE_LEAFS, TREE_ALPHAS):
        min_leaf, min_split = leaf_params(n_init, leaf)
        model = DecisionTreeRegressor(
            criterion="squared_error", splitter="best", max_features=None, random_state=42,
            max_depth=depth, min_samples_leaf=min_leaf, min_samples_split=min_split, ccp_alpha=alpha,
        ).fit(X_init, y_init)
        pred = model.predict(X_val)
        m = mse(y_val[val_eval_mask], pred[val_eval_mask])
        rec = {
            "model": "Tree", "candidate_id": tree_id(depth, leaf, alpha),
            "max_depth": depth, "min_leaf_fraction": leaf, "ccp_alpha": alpha,
            "n_leaves": int(model.get_n_leaves()), "max_depth_actual": int(model.get_depth()),
            "val_mse": m,
        }
        tree_grid.append(rec)
        grid_rows.append(rec)
        if len(tree_grid) % 15 == 0:
            print(f"  trees {len(tree_grid)}/75", flush=True)

    def tree_tie(pool, grid=tree_grid):
        lookup = {r["candidate_id"]: r for r in grid}
        return sorted(pool, key=lambda cid: (
            lookup[cid]["n_leaves"], lookup[cid]["max_depth_actual"],
            -lookup[cid]["ccp_alpha"], -lookup[cid]["min_leaf_fraction"],
            99 if lookup[cid]["max_depth"] is None else lookup[cid]["max_depth"], cid,
        ))[0]

    tree_sel, tree_best, _ = close_best({r["candidate_id"]: r["val_mse"] for r in tree_grid}, tree_tie)
    best_tree = next(r for r in tree_grid if r["candidate_id"] == tree_sel)
    min_leaf, min_split = leaf_params(n_init, best_tree["min_leaf_fraction"])
    tree_init = DecisionTreeRegressor(
        criterion="squared_error", splitter="best", max_features=None, random_state=42,
        max_depth=best_tree["max_depth"], min_samples_leaf=min_leaf,
        min_samples_split=min_split, ccp_alpha=best_tree["ccp_alpha"],
    ).fit(X_init, y_init)
    p_val["Tree"] = tree_init.predict(X_val)
    print("selected tree", tree_sel, tree_best, flush=True)

    def eval_val(pred):
        return mse(y_val[val_eval_mask], pred[val_eval_mask])

    print("bagging/rf...", flush=True)
    forest_specs = []
    for depth, leaf, B in product([5, None], [0.01], [100]):
        forest_specs.append(("Bagging", depth, leaf, 36, B))
    for depth, leaf, m, B in product([5], [0.01], [6, 12, 18], [100]):
        forest_specs.append(("RF", depth, leaf, m, B))
    forest_models = {}
    for name, depth, leaf, mfeat, B in forest_specs:
        min_leaf, min_split = leaf_params(n_init, leaf)
        cid = f"{name}:depth={depth}:leaf={leaf}:m={mfeat}:B={B}"
        print(" fit", cid, flush=True)
        model = RandomForestRegressor(
            n_estimators=B, max_depth=depth, max_features=mfeat,
            min_samples_leaf=min_leaf, min_samples_split=min_split,
            criterion="squared_error", bootstrap=True, max_samples=1.0,
            ccp_alpha=0, random_state=42, n_jobs=N_JOBS,
        )
        t1 = time.time()
        model.fit(X_init, y_init)
        pred = model.predict(X_val)
        m = eval_val(pred)
        rec = {"model": name, "candidate_id": cid, "max_depth": depth, "leaf": leaf,
               "max_features": mfeat, "B": B, "val_mse": m, "sec": time.time() - t1}
        grid_rows.append(rec)
        forest_models[cid] = {"spec": rec, "model": model, "val_pred": pred}
        print("  mse", m, f"{rec['sec']:.1f}s", flush=True)

    selected_forest = {}
    for family in ("Bagging", "RF"):
        subset = {k: v for k, v in forest_models.items() if v["spec"]["model"] == family}
        mse_map = {k: v["spec"]["val_mse"] for k, v in subset.items()}
        def prefer(pool, subset=subset):
            return sorted(pool, key=lambda cid: (subset[cid]["spec"]["B"], cid))[0]
        sel, best, _ = close_best(mse_map, prefer)
        selected_forest[family] = sel
        p_val[family] = subset[sel]["val_pred"]
        fitted[family] = subset[sel]
        print("selected", family, sel, best, flush=True)

    print("adaboost.r2...", flush=True)
    ada_models = {}
    for depth, lr, M in product([2], [0.03, 0.1], [50]):
        min_leaf, min_split = leaf_params(n_init, 0.01)
        cid = f"AdaBoost_R2:depth={depth}:lr={lr}:M={M}"
        print(" fit", cid, flush=True)
        base = DecisionTreeRegressor(
            max_depth=depth, min_samples_leaf=min_leaf, min_samples_split=min_split,
            random_state=42,
        )
        model = AdaBoostRegressor(
            estimator=base, n_estimators=M, learning_rate=lr, loss="linear", random_state=42,
        )
        t1 = time.time()
        model.fit(X_init, y_init)
        pred = model.predict(X_val)
        m = eval_val(pred)
        rec = {"model": "AdaBoost_R2", "candidate_id": cid, "max_depth": depth,
               "learning_rate": lr, "M": M, "actual_M": int(len(model.estimators_)),
               "val_mse": m, "sec": time.time() - t1}
        grid_rows.append(rec)
        ada_models[cid] = {"spec": rec, "model": model, "val_pred": pred}
        print("  mse", m, f"{rec['sec']:.1f}s", flush=True)
    ada_sel, ada_best, _ = close_best({k: v["spec"]["val_mse"] for k, v in ada_models.items()}, lambda p: sorted(p)[0])
    p_val["AdaBoost_R2"] = ada_models[ada_sel]["val_pred"]
    fitted["AdaBoost_R2"] = ada_models[ada_sel]
    print("selected AdaBoost_R2", ada_sel, ada_best, flush=True)

    print("gbrt...", flush=True)
    gbrt_models = {}
    for depth, lr, sub, M in product([2], [0.03, 0.1], [1.0], [100]):
        min_leaf, min_split = leaf_params(n_init, 0.01)
        cid = f"GBRT:depth={depth}:lr={lr}:sub={sub}:M={M}"
        print(" fit", cid, flush=True)
        model = GradientBoostingRegressor(
            loss="squared_error", criterion="friedman_mse", max_features=None,
            max_depth=depth, learning_rate=lr, subsample=sub, n_estimators=M,
            min_samples_leaf=min_leaf, min_samples_split=min_split,
            ccp_alpha=0, n_iter_no_change=None, random_state=42,
        )
        t1 = time.time()
        model.fit(X_init, y_init)
        pred = model.predict(X_val)
        m = eval_val(pred)
        rec = {"model": "GBRT", "candidate_id": cid, "max_depth": depth, "learning_rate": lr,
               "subsample": sub, "M": M, "val_mse": m, "sec": time.time() - t1}
        grid_rows.append(rec)
        gbrt_models[cid] = {"spec": rec, "model": model, "val_pred": pred}
        print("  mse", m, f"{rec['sec']:.1f}s", flush=True)
    gbrt_sel, gbrt_best, _ = close_best({k: v["spec"]["val_mse"] for k, v in gbrt_models.items()}, lambda p: sorted(p)[0])
    p_val["GBRT"] = gbrt_models[gbrt_sel]["val_pred"]
    fitted["GBRT"] = gbrt_models[gbrt_sel]
    print("selected GBRT", gbrt_sel, gbrt_best, flush=True)

    xgb_models = {}
    if XGBRegressor is not None:
        print("xgboost...", flush=True)
        for depth, lr, sub, M in product([2], [0.03, 0.1], [1.0], [100]):
            cid = f"XGBoost:depth={depth}:lr={lr}:sub={sub}:M={M}"
            print(" fit", cid, flush=True)
            model = XGBRegressor(
                objective="reg:squarederror", booster="gbtree", tree_method="hist",
                device="cpu", max_depth=depth, learning_rate=lr, subsample=sub,
                n_estimators=M, colsample_bytree=0.75, colsample_bylevel=1, colsample_bynode=1,
                min_child_weight=int(np.ceil(0.005 * n_init)),
                reg_alpha=0, reg_lambda=1, gamma=0, max_bin=256, random_state=42,
                base_score=mean_init, n_jobs=N_JOBS, verbosity=0,
            )
            t1 = time.time()
            model.fit(X_init, y_init)
            pred = model.predict(X_val)
            m = eval_val(pred)
            rec = {"model": "XGBoost", "candidate_id": cid, "max_depth": depth, "learning_rate": lr,
                   "subsample": sub, "M": M, "val_mse": m, "sec": time.time() - t1}
            grid_rows.append(rec)
            xgb_models[cid] = {"spec": rec, "model": model, "val_pred": pred}
            print("  mse", m, f"{rec['sec']:.1f}s", flush=True)
        xgb_sel, xgb_best, _ = close_best({k: v["spec"]["val_mse"] for k, v in xgb_models.items()}, lambda p: sorted(p)[0])
        p_val["XGBoost"] = xgb_models[xgb_sel]["val_pred"]
        fitted["XGBoost"] = xgb_models[xgb_sel]
        print("selected XGBoost", xgb_sel, xgb_best, flush=True)
    else:
        print("xgboost missing", flush=True)

    lgb_models = {}
    if LGBMRegressor is not None:
        print("lightgbm...", flush=True)
        for leaves, lr, bag, M in product([15], [0.03, 0.1], [1.0], [100]):
            cid = f"LightGBM:leaves={leaves}:lr={lr}:bag={bag}:M={M}"
            print(" fit", cid, flush=True)
            model = LGBMRegressor(
                objective="regression", boosting_type="gbdt", data_sample_strategy="bagging",
                num_leaves=leaves, learning_rate=lr, n_estimators=M,
                subsample=bag, subsample_freq=0 if bag >= 1 else 1,
                min_child_samples=int(np.ceil(0.01 * n_init)), min_child_weight=1e-3,
                colsample_bytree=0.75, reg_alpha=0, reg_lambda=1, max_bin=255,
                boost_from_average=True, deterministic=True, force_col_wise=True,
                enable_bundle=False, random_state=42, n_jobs=N_JOBS, verbosity=-1,
            )
            t1 = time.time()
            model.fit(X_init, y_init)
            pred = model.predict(X_val)
            m = eval_val(pred)
            rec = {"model": "LightGBM", "candidate_id": cid, "num_leaves": leaves, "learning_rate": lr,
                   "bagging_fraction": bag, "M": M, "val_mse": m, "sec": time.time() - t1}
            grid_rows.append(rec)
            lgb_models[cid] = {"spec": rec, "model": model, "val_pred": pred}
            print("  mse", m, f"{rec['sec']:.1f}s", flush=True)
        lgb_sel, lgb_best, _ = close_best({k: v["spec"]["val_mse"] for k, v in lgb_models.items()}, lambda p: sorted(p)[0])
        p_val["LightGBM"] = lgb_models[lgb_sel]["val_pred"]
        fitted["LightGBM"] = lgb_models[lgb_sel]
        print("selected LightGBM", lgb_sel, lgb_best, flush=True)
    else:
        print("lightgbm missing", flush=True)

    print("refit selected...", flush=True)
    p_test = {}
    min_leaf_f, min_split_f = leaf_params(n_final, best_tree["min_leaf_fraction"])
    tree_final = DecisionTreeRegressor(
        criterion="squared_error", splitter="best", max_features=None, random_state=42,
        max_depth=best_tree["max_depth"], min_samples_leaf=min_leaf_f,
        min_samples_split=min_split_f, ccp_alpha=best_tree["ccp_alpha"],
    ).fit(X_final, y_final)
    ols_fi, ols_fb = fit_ols(X_final, y_final)
    ridge_fi, ridge_fb = fit_ridge(X_final, y_final, lam_star)
    ep_fi, ep_fb = fit_ols(final.ep_neutral_z.to_numpy()[:, None], y_final)
    p_test["OLS"] = predict_linear(ols_fi, ols_fb, X_test)
    p_test["Ridge"] = predict_linear(ridge_fi, ridge_fb, X_test)
    p_test["Tree"] = tree_final.predict(X_test)
    p_test["EP_OLS"] = ep_fi + ep_fb[0] * test_feat.ep_neutral_z.to_numpy()
    p_test["FrozenMean"] = np.full(len(test_feat), mean_final)
    p_test["EP_score"] = test_feat.ep_neutral_z.to_numpy()

    final_models = {"Tree": tree_final}
    for family in ("Bagging", "RF"):
        spec = fitted[family]["spec"]
        min_leaf, min_split = leaf_params(n_final, spec["leaf"])
        model = RandomForestRegressor(
            n_estimators=spec["B"], max_depth=spec["max_depth"], max_features=spec["max_features"],
            min_samples_leaf=min_leaf, min_samples_split=min_split,
            criterion="squared_error", bootstrap=True, max_samples=1.0,
            ccp_alpha=0, random_state=42, n_jobs=N_JOBS,
        )
        print(" refit", family, flush=True)
        model.fit(X_final, y_final)
        p_test[family] = model.predict(X_test)
        final_models[family] = model

    spec = fitted["AdaBoost_R2"]["spec"]
    min_leaf, min_split = leaf_params(n_final, 0.01)
    base = DecisionTreeRegressor(max_depth=spec["max_depth"], min_samples_leaf=min_leaf, min_samples_split=min_split, random_state=42)
    ada_final = AdaBoostRegressor(estimator=base, n_estimators=spec["M"], learning_rate=spec["learning_rate"], loss="linear", random_state=42)
    print(" refit AdaBoost_R2", flush=True)
    ada_final.fit(X_final, y_final)
    p_test["AdaBoost_R2"] = ada_final.predict(X_test)
    final_models["AdaBoost_R2"] = ada_final

    spec = fitted["GBRT"]["spec"]
    min_leaf, min_split = leaf_params(n_final, 0.01)
    gbrt_final = GradientBoostingRegressor(
        loss="squared_error", criterion="friedman_mse", max_features=None,
        max_depth=spec["max_depth"], learning_rate=spec["learning_rate"], subsample=spec["subsample"],
        n_estimators=spec["M"], min_samples_leaf=min_leaf, min_samples_split=min_split,
        ccp_alpha=0, n_iter_no_change=None, random_state=42,
    )
    print(" refit GBRT", flush=True)
    gbrt_final.fit(X_final, y_final)
    p_test["GBRT"] = gbrt_final.predict(X_test)
    final_models["GBRT"] = gbrt_final

    if "XGBoost" in fitted:
        spec = fitted["XGBoost"]["spec"]
        xgb_final = XGBRegressor(
            objective="reg:squarederror", booster="gbtree", tree_method="hist", device="cpu",
            max_depth=spec["max_depth"], learning_rate=spec["learning_rate"], subsample=spec["subsample"],
            n_estimators=spec["M"], colsample_bytree=0.75, min_child_weight=int(np.ceil(0.005 * n_final)),
            reg_alpha=0, reg_lambda=1, gamma=0, max_bin=256, random_state=42,
            base_score=mean_final, n_jobs=N_JOBS, verbosity=0,
        )
        print(" refit XGBoost", flush=True)
        xgb_final.fit(X_final, y_final)
        p_test["XGBoost"] = xgb_final.predict(X_test)
        final_models["XGBoost"] = xgb_final
    if "LightGBM" in fitted:
        spec = fitted["LightGBM"]["spec"]
        lgb_final = LGBMRegressor(
            objective="regression", boosting_type="gbdt", data_sample_strategy="bagging",
            num_leaves=spec["num_leaves"], learning_rate=spec["learning_rate"], n_estimators=spec["M"],
            subsample=spec["bagging_fraction"], subsample_freq=0 if spec["bagging_fraction"] >= 1 else 1,
            min_child_samples=int(np.ceil(0.01 * n_final)), min_child_weight=1e-3,
            colsample_bytree=0.75, reg_alpha=0, reg_lambda=1, max_bin=255,
            boost_from_average=True, deterministic=True, force_col_wise=True,
            enable_bundle=False, random_state=42, n_jobs=N_JOBS, verbosity=-1,
        )
        print(" refit LightGBM", flush=True)
        lgb_final.fit(X_final, y_final)
        p_test["LightGBM"] = lgb_final.predict(X_test)
        final_models["LightGBM"] = lgb_final

    model_rows, month_rows = [], []
    for stage, preds, y, months, bench in (
        ("validation", p_val, y_val, months_val, mean_init),
        ("teaching_test", p_test, y_test, months_test, mean_final),
    ):
        for name, pred in preds.items():
            ranking = name == "EP_score"
            constant = name == "FrozenMean"
            met = metrics(pred, y, months, bench, constant=constant, ranking_only=ranking)
            model_rows.append({"model": name, "stage": stage, **met})
            month_rows.extend(monthly_rows(pred, y, months, name, stage))

    pd.DataFrame(tree_grid).to_csv(OUT / "tree-grid.csv", index=False)
    pd.DataFrame(grid_rows).to_csv(OUT / "ensemble-grid.csv", index=False)
    pd.DataFrame(model_rows).to_csv(OUT / "stock-model-metrics.csv", index=False)
    pd.DataFrame(month_rows).to_csv(OUT / "stock-monthly-metrics.csv", index=False)

    if "RF" in final_models:
        names = st_final["feature_names"]
        mdi = final_models["RF"].feature_importances_
        pd.DataFrame({"feature": names, "mdi": mdi}).to_csv(OUT / "rf-importance.csv", index=False)

    example_idx = []
    for ym in DISPLAY_MONTHS:
        loc = np.where(test_feat.ym.astype(str).to_numpy() == ym)[0]
        example_idx.extend(list(loc[:3]))
    examples = []
    for j in example_idx:
        row = test_feat.iloc[j]
        rec = {
            "row_key": row.row_key, "ts_code": row.ts_code, "name": row["name"], "ym": str(row.ym),
            "y": finite_num(row.ret_open_1m),
        }
        for name, pred in p_test.items():
            rec[f"pred_{name}"] = finite_num(pred[j])
        examples.append(rec)
    dump(examples, OUT / "examples.json")

    if examples and "GBRT" in final_models:
        j = example_idx[0]
        xone = X_test[j:j + 1]
        rows = []
        for model_name, key in (("GBRT", "GBRT"), ("XGBoost", "XGBoost"), ("LightGBM", "LightGBM")):
            if key not in final_models:
                continue
            model = final_models[key]
            if model_name == "GBRT":
                F = np.full(1, model.init_.constant_.ravel()[0])
                rows.append({"model": model_name, "round": 0, "F": float(F[0]), "delta": None})
                for m, est in enumerate(model.estimators_, start=1):
                    delta = model.learning_rate * est[0].predict(xone)
                    F = F + delta
                    rows.append({"model": model_name, "round": m, "F": float(F[0]), "delta": float(delta[0])})
            elif model_name == "XGBoost":
                f0 = float(mean_final)
                rows.append({"model": model_name, "round": 0, "F": f0, "delta": None})
                prev = f0
                n_est = int(model.get_params()["n_estimators"])
                for m in range(1, n_est + 1):
                    cur = float(model.predict(xone, iteration_range=(0, m))[0])
                    rows.append({"model": model_name, "round": m, "F": cur, "delta": cur - prev})
                    prev = cur
            else:
                f0 = float(mean_final)
                rows.append({"model": model_name, "round": 0, "F": f0, "delta": None})
                prev = f0
                n_est = int(model.get_params()["n_estimators"])
                for m in range(1, n_est + 1):
                    cur = float(model.predict(xone, num_iteration=m)[0])
                    rows.append({"model": model_name, "round": m, "F": cur, "delta": cur - prev})
                    prev = cur
        pd.DataFrame(rows).to_csv(OUT / "boosting-decomp.csv", index=False)
        dump({"row_key": examples[0]["row_key"], "note": "F0+sum(delta) should recover predict"}, OUT / "boosting-decomp-meta.json")

    if examples and "RF" in final_models:
        j = example_idx[0]
        xone = X_test[j:j + 1]
        votes = []
        for family in ("Bagging", "RF"):
            model = final_models[family]
            for b, est in enumerate(model.estimators_):
                votes.append({"model": family, "tree": b, "pred": float(est.predict(xone)[0])})
        pd.DataFrame(votes).to_csv(OUT / "forest-votes.csv", index=False)

    selected = {
        "Tree": tree_sel,
        "Ridge_lambda": lam_star,
        "Bagging": selected_forest.get("Bagging"),
        "RF": selected_forest.get("RF"),
        "AdaBoost_R2": ada_sel,
        "GBRT": gbrt_sel,
        "XGBoost": fitted["XGBoost"]["spec"]["candidate_id"] if "XGBoost" in fitted else None,
        "LightGBM": fitted["LightGBM"]["spec"]["candidate_id"] if "LightGBM" in fitted else None,
    }
    interaction = {
        "schema_version": "ml4-1.0",
        "status": "computed",
        "identity": "new_stock_run",
        "input_sha256": sha,
        "n_init": n_init, "n_val_predict": int(len(val_feat)), "n_val_eval": int(val_eval_mask.sum()),
        "n_final": n_final, "n_test_predict": int(len(test_feat)), "n_test_eval": int(test_eval_mask.sum()),
        "selected": selected,
        "metrics": model_rows,
        "examples": examples,
        "grid_note": "Core teaching grid on the full sample: Tree 75, Ridge 19, Bagging 2, RF 3, AdaR2 2, GBRT 2, XGB 2, LGB 2. Not the full 222-candidate contract.",
        "seconds": time.time() - t0,
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }
    dump(interaction, OUT / "interaction-data.json")
    dump(selected, OUT / "selected.json")
    print("done in", round(time.time() - t0, 1), "s", flush=True)


if __name__ == "__main__":
    main()
