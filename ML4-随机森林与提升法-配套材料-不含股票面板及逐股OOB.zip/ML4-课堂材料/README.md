# ML4：随机森林与提升法课堂材料

打开[投影课件](slides-ml4.html)，配合 [ML4 Notebook](notebooks/ML4-随机森林与提升法.ipynb)，Notebook 前半按当前 80 页课件顺序提供可编辑文字、公式和局部图表；后半为独立的“补充阅读与实验”，保留进一步解释、数学推导、19 个代码单元与课堂作答。实验区按前后依赖排列，与投影页序分开，运行时从第一个代码单元开始依次执行。代码单元复算模拟、读取课程试算结果，并检查样本数和预测分解。股票模型拟合入口是 <code>scripts/compute_models.py</code>。第 73 页的袋外诊断在 Notebook 中用包内保存的逐行预测复核；该拟合脚本不生成袋外诊断文件。

| 课件页 | Notebook 主题 |
| --- | --- |
| 1–6 | 导入与预测误差 |
| 7–17 | 装袋与袋外评价 |
| 18–25 | 随机森林与解释 |
| 26–37 | 二分类 AdaBoost 与加法模型 |
| 38–46 | 回归提升与损失 |
| 47–62 | 梯度提升与 XGBoost |
| 63–67 | 随机梯度提升 |
| 68–69 | 关系总结与扩展 |
| 70–78 | 股票案例 |
| 79–80 | 参考与致谢 |

## 运行

本公开包不含原始股票面板和逐股袋外（OOB）结果。无需补齐数据，即可阅读投影课件、离线交互与 Notebook 的已有输出；若需完全离线投影，可使用发放页另附的独立课件 HTML。

从头运行 Notebook 的全部 19 个代码单元前，向教师领取 `ML4-随机森林与提升法-课堂数据.zip`，把其中的 `ML4-课堂材料/` 内容合并到本包同名文件夹。补充包提供两项文件：`data/ep_ml_panel.parquet` 和 `output/forest-oob.parquet`。需保留这两层路径；只放入股票面板仍不能运行袋外核验单元。详见[数据说明](data/README.md)。

无数据时可以阅读全部已有输出、运行前 10 个机制实验代码单元；第 11 个代码单元开始读取股票面板。数据齐全后，从第一个代码单元依次执行全部 19 个单元，不跳过前面的共同准备。Notebook 复核样本、教学汇总和预测分解；股票模型重新拟合由下列独立脚本完成，逐股 OOB 文件仍使用教师提供的已保存诊断结果。


在本 README 所在目录启动 JupyterLab 或 VS Code，选择已安装依赖的 Python 内核，打开 Notebook 后按单元运行。数据与计算均在本地完成。

```sh
python -m pip install -r requirements.txt
```

macOS 上 XGBoost / LightGBM 还需要 OpenMP 运行库，可用 `brew install libomp`。输入只读。输出已写入 `output/` 与 `figures/`。若需要重算，在安装 `pyarrow`、`xgboost` 与 `lightgbm` 的环境中运行 `python3 scripts/compute_models.py`。脚本按本课堂材料目录定位 `data/`。

当前主榜是完整样本上的教学网格：Tree 75、Ridge 19、Bagging 2、RF 3、AdaBoost.R2 2、GBRT 2、XGBoost 2、LightGBM 2。这不是规格里全部 222 个候选。

## 文件

| 位置 | 内容 |
| --- | --- |
| `notebooks/ML4-随机森林与提升法.ipynb` | 课件逐页阅读、模拟复算与案例核验 |
| `data/ep_ml_panel.parquet` | 课堂数据包提供，公开包不含 |
| `data/source-manifest.json` | 来源与 SHA-256 |
| `output/stock-model-metrics.csv` | 个股任务各阶段指标 |
| `output/ensemble-grid.csv` | 教学网格候选的验证 MSE |
| `output/tree-grid.csv` | 75 个回归树候选的验证 MSE |
| `output/stock-monthly-metrics.csv` | 逐月误差与 Rank IC |
| `output/forest-diagnostics.json` | 初次训练 Bagging/RF 的 OOB 覆盖与 MSE |
| `output/forest-oob.parquet` | 课堂数据包提供的逐股 OOB 结果，公开包不含 |
| `output/interaction-data.json` | 交互页使用的结构化结果 |
| `figures/` | 局部原图、课堂解释图与应用图 |
| [离线交互](web/ML4-随机森林与提升法-交互.html) | 53 段原文、机制实验与真实试算实验室 |

## 学习任务

1. 说明有放回抽 n 次为什么不是每条记录都出现一次，OOB 预测只用未抽中该行的树。
2. 指出随机特征发生在每次分裂，而不是整棵树开始时抽一次。
3. 区分分类 AdaBoost 的加权错分、AdaBoost.R2 的加权中位数，以及 梯度提升的初值加逐轮增量。
4. 对同一组残差计算半平方、绝对和 Huber 损失的准残差，比较阈值两侧的变化。
5. 对同一条股票记录，比较随机森林各树平均和 GBRT 的 F0+增量，并说明当前材料不能支持的结论。
6. 解释为什么训练池里的 OOB 不能替代按时间切开的验证。

学生本人解释实际输出。Notebook 不代填理解或人工审阅状态。

## 数据与结果边界

- 个股任务沿用 ML1–ML3 的 36 列设计矩阵与时间边界。
- 股票主任务保持连续收益，不改成涨跌。分类 AdaBoost 仅用于理论与机制实验，不用于股票连续收益主任务。
- EP_score 只用于排序。逐月表给出每月的 Rank IC，汇总表按有效月份等权平均；两张表的收益 MSE 均留空。FrozenMean 的预测恒定，Rank IC 未定义。
- 教学测试曾用于课程比较。净值、扣费收益和夏普需另行指定交易规则与成本。
- 主股票 LightGBM 关闭 GOSS 与 EFB。交互页的 GOSS 只是机制展示。
