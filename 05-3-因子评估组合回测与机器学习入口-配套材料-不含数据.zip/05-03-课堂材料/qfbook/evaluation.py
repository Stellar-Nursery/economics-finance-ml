"""数值辅助与读取规则。表格处理使用 Polars，数值运算使用 NumPy。"""

import csv
import numpy as np
import polars as pl


def read_table(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        names = next(csv.reader(stream))
    text_names = {
        "ym",
        "ts_code",
        "t_signal",
        "t_enter",
        "t_exit",
        "t_enter_d1",
        "t_exit_d1",
    }
    overrides = {name: pl.String for name in names if name in text_names}
    return pl.read_csv(path, schema_overrides=overrides, infer_schema_length=None)


def sample_zscore(x):
    x = np.asarray(x, dtype=float)
    valid = x[np.isfinite(x)]
    if len(valid) < 2 or np.ptp(valid) == 0:
        raise ValueError("退化截面无法标准化")
    mean, sd = np.nanmean(x), np.nanstd(x, ddof=1)
    if not np.isfinite(sd) or sd < 1e-15:
        raise ValueError("退化截面无法标准化")
    return (x - mean) / sd


def winsorize_01_99(x):
    x = np.asarray(x, dtype=float)
    lo, hi = np.nanquantile(x, [0.01, 0.99])
    return np.clip(x, lo, hi), float(lo), float(hi)


def pearson_ic(x, y):
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    valid = np.isfinite(x) & np.isfinite(y)
    x, y = x[valid], y[valid]
    if len(x) < 3 or np.ptp(x) == 0 or np.ptp(y) == 0:
        return np.nan
    return float(np.corrcoef(x, y)[0, 1])


def spearman_rank_ic(x, y):
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    valid = np.isfinite(x) & np.isfinite(y)
    if valid.sum() < 3:
        return np.nan
    rx = pl.Series(x[valid]).rank(method="average").to_numpy()
    ry = pl.Series(y[valid]).rank(method="average").to_numpy()
    return pearson_ic(rx, ry)


def newey_west_t(series, maxlags=4):
    a = np.asarray(series, dtype=float)
    a = a[np.isfinite(a)]
    n = len(a)
    if n < 2:
        return {"n": n, "mean": np.nan, "t_iid": np.nan, "t_hac": np.nan}
    mean, sd = float(a.mean()), float(a.std(ddof=1))
    se_iid = sd / np.sqrt(n)
    u = a - mean
    q = min(maxlags, n - 1)
    lrv = float(u @ u / n)
    for k in range(1, q + 1):
        lrv += 2 * (1 - k / (q + 1)) * float(u[k:] @ u[:-k] / n)
    # 与本讲参考表一致，采用 n/(n-1) 有限样本校正。
    se_hac = float(np.sqrt(max(lrv, 0) / n * n / (n - 1)))
    return {
        "n": n,
        "mean": mean,
        "std": sd,
        "t_iid": mean / se_iid if se_iid > 0 else np.nan,
        "t_hac": mean / se_hac if se_hac > 0 else np.nan,
        "maxlags": q,
    }


def compute_half_life(values_by_h, direction=1):
    arr = np.asarray(values_by_h, dtype=float)
    if not len(arr):
        raise ValueError("衰减序列不能为空")
    q = direction * arr
    if not np.isfinite(q[0]) or q[0] <= 0:
        return {"half_life_h": None, "status": "not_applicable_nonpositive_baseline"}
    hits = np.flatnonzero(q[1:] <= q[0] / 2)
    if len(hits):
        h = int(hits[0] + 2)
        if not np.isfinite(q[:h]).all():
            return {"half_life_h": None, "status": "missing_before_crossing"}
        return {
            "half_life_h": h,
            "half_life_lag_tau": h - 1,
            "status": "crossed",
            "baseline_h1": float(arr[0]),
            "half_threshold": float(q[0] / 2),
        }
    return {
        "half_life_h": None,
        "status": (
            "missing_windows"
            if not np.isfinite(q).all()
            else "not_observed_within_window"
        ),
        "baseline_h1": float(arr[0]),
        "half_threshold": float(q[0] / 2),
    }


def max_drawdown_from_nav(nav):
    nav = np.asarray(nav, dtype=float)
    if not len(nav) or not np.isfinite(nav).all() or np.any(nav <= 0):
        raise ValueError("净值必须为完整的正数序列，并包含期初净值")
    hwm = np.maximum.accumulate(nav)
    dd = nav / hwm - 1
    trough = int(np.argmin(dd))
    peak = int(np.argmax(nav[: trough + 1]))
    return {"mdd": float(dd[trough]), "peak_idx": peak, "trough_idx": trough}


def assign_quantile(df, score_col="ep_neutral_z", q=5):
    if df.is_empty():
        raise ValueError("分组样本不能为空")
    d = df.sort([score_col, "ts_code"])
    return d.with_columns(pl.Series("group", np.arange(d.height) * q // d.height + 1))


def monthly_rank_ic(panel, return_col="ret_open_1m"):
    rows = []
    for key, group in (
        panel.sort("ym").partition_by("ym", as_dict=True, maintain_order=True).items()
    ):
        rows.append(
            {
                "ym": key[0],
                "rank_ic": spearman_rank_ic(group["ep_neutral_z"], group[return_col]),
            }
        )
    return pl.DataFrame(rows).sort("ym")


def target_exposure(panel, month="202512"):
    current = assign_quantile(panel.filter(pl.col("ym") == month))
    pool = (
        current.group_by("l1_name")
        .len()
        .with_columns((pl.col("len") / current.height).alias("pool_target_weight"))
        .drop("len")
    )
    high = current.filter(pl.col("group") == 5)
    q5 = (
        high.group_by("l1_name")
        .len()
        .with_columns((pl.col("len") / high.height).alias("Q5_target_weight"))
        .drop("len")
    )
    return (
        pool.join(q5, on="l1_name", how="left")
        .with_columns(pl.col("Q5_target_weight").fill_null(0))
        .with_columns(
            (pl.col("Q5_target_weight") - pl.col("pool_target_weight")).alias(
                "active_weight"
            )
        )
        .sort("active_weight", descending=True)
    )


def validate_panel(frame):
    if frame.select(["ts_code", "ym"]).is_duplicated().any():
        raise ValueError("重复股票-月份键；停止并核查来源")
    if not frame.select(
        pl.col("ret_open_1m").is_finite().fill_null(False).any()
    ).item():
        raise ValueError("没有任何成熟收益标签；停止评价")
