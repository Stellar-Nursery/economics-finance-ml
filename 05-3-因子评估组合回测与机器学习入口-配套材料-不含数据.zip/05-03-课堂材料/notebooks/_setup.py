"""从文件位置定位资料包，不依赖个人绝对路径。"""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
DATA = ROOT / "data" / "offline"
FIGURES = ROOT / "figures"
OUTPUT = ROOT / "output"
FIGURES.mkdir(exist_ok=True)
OUTPUT.mkdir(exist_ok=True)
if not (DATA / "ep_monthly_panel_teaching.parquet").is_file():
    raise FileNotFoundError(
        "缺少 data/offline/ep_monthly_panel_teaching.parquet。"
        "请按README将05-03数据包解压到资料包根目录。"
    )
