# %%
import _setup
import json
import platform
import numpy as np
import polars as pl
import matplotlib.pyplot as plt
from IPython.display import display
from qfbook.evaluation import (
    read_table,
    sample_zscore,
    winsorize_01_99,
    pearson_ic,
    spearman_rank_ic,
    newey_west_t,
    compute_half_life,
    max_drawdown_from_nav,
    assign_quantile,
    monthly_rank_ic,
    target_exposure,
    validate_panel,
)

DATA, FIGURES, OUT = _setup.DATA, _setup.FIGURES, _setup.OUTPUT
pl.Config.set_tbl_rows(12)
pl.Config.set_tbl_cols(12)
pl.Config.set_float_precision(6)
font = {"Darwin": "PingFang SC", "Windows": "SimHei"}.get(
    platform.system(), "WenQuanYi Micro Hei"
)
plt.rcParams.update(
    {
        "font.sans-serif": [font, "DejaVu Sans"],
        "axes.unicode_minus": False,
        "figure.figsize": (9, 4.2),
        "axes.grid": True,
    }
)


def show_figure(fig, filename):
    fig.tight_layout()
    fig.savefig(FIGURES / filename)
    display(fig)
    plt.close(fig)


panel = pl.read_parquet(DATA / "ep_monthly_panel_teaching.parquet")
cal = read_table(DATA / "ep_monthly_calendar.csv")
RESULT_STATUS = json.loads((DATA / "result-status.json").read_text())
print("panel shape:", panel.shape)
print("months:", panel["ym"].n_unique(), panel["ym"].min(), "→", panel["ym"].max())
display(panel.group_by("split").len().sort("split"))
display(
    cal.group_by("split")
    .agg(
        pl.len().alias("months"),
        pl.col("ym").min().alias("first"),
        pl.col("ym").max().alias("last"),
    )
    .sort("first")
)
display(
    cal.filter(
        pl.col("ym").is_in(["201501", "201912", "202001", "202212", "202301", "202512"])
    ).select("ym", "t_signal", "t_enter", "t_exit", "split", "cross_split_boundary")
)
assert panel.height == 365982 and panel["ym"].n_unique() == 132
validate_panel(panel)
print("EP统计状态：", RESULT_STATUS["ep_statistics"])
print("组合暂停原因：", RESULT_STATUS["portfolio_reason"])
print("ROE暂停原因：", RESULT_STATUS["roe_reason"])

# %%
# Sec1-Cell1：EP定义与评价对象
chk = panel.select("pe_ttm", "ep_raw").drop_nulls().head(8)
assert np.allclose(chk["ep_raw"].to_numpy(), 1 / chk["pe_ttm"].to_numpy())
assert panel["pe_ttm"].min() > 0
print("EP定义核验通过：ep_raw = 1/pe_ttm，且pe_ttm>0。")
display(
    pl.DataFrame(
        {
            "概念": ["特征", "得分", "组合权重", "组合收益", "评价统计"],
            "例子": [
                "EP",
                "缩尾中性化后的ep_neutral_z",
                "等权或市值加权",
                "持有期实现收益",
                "IC / ICIR / IR",
            ],
        }
    )
)
print("先沿EP完成评价流程，第12节再用EP＋ROE引出学习得分。")

# %%
# Sec2-Cell1
mini = read_table(DATA / "example_ch04_02_mini_panel.csv")
display(mini)
period_cols = ["2020-09", "2020-10", "2020-11", "2020-12"]
print("各期非缺失股票数:", {c: mini[c].drop_nulls().len() for c in period_cols})
display(mini.select("stock", "missing_type", "reason"))

# %%
# Sec2-Cell2
funnel = read_table(DATA / "ep_funnel_summary.csv")
display(funnel)
for key in ["n_e_positive_pe", "n_f_paired_return"]:
    row = funnel.filter(pl.col("metric") == key).row(0, named=True)
    print(
        key,
        "首月",
        row["first_month_201501"],
        "代表月",
        row["repr_month_202512"],
        "均值",
        round(row["mean_132m"], 1),
    )

# %%
# Sec2-Cell3
cov = read_table(DATA / "ep_coverage_monthly.csv")
display(
    cov.select(
        "ym",
        "n_d_valid_mv_ind",
        "n_e_positive_pe",
        "ep_coverage_in_qualified",
        "paired_label_rate_in_ep",
    ).head()
)
fig, ax = plt.subplots()
ax.plot(
    cov["ym"].str.strptime(pl.Date, "%Y%m").to_numpy(),
    cov["ep_coverage_in_qualified"].to_numpy(),
)
ax.set_title("合格池内EP覆盖率 (e)/(d)")
fig.autofmt_xdate()
show_figure(fig, "sec2_coverage.pdf")

# %%
# Sec2-Cell4
display(
    cal.group_by("split")
    .agg(
        pl.len().alias("n"),
        pl.col("ym").min().alias("ym0"),
        pl.col("ym").max().alias("ym1"),
    )
    .sort("ym0")
)
display(
    cal.filter(pl.col("cross_split_boundary")).select(
        "ym", "t_signal", "t_enter", "t_exit", "split"
    )
)
print("按信号月分期不等于标签已实现。训练时只使用决策前已完成持有期的样本。")

# %%
# Sec3-Cell1
sub = panel.filter(pl.col("ym") == "202512")
x = sub["ep_raw"].to_numpy()
xw, lo, hi = winsorize_01_99(x)
xz = sample_zscore(xw)
assert np.allclose(sub["ep_win_z"].to_numpy(), xz, atol=1e-10)
print("1% / 99%:", lo, hi)
print("mean / sample sd:", xz.mean(), xz.std(ddof=1))
fig, axes = plt.subplots(1, 3, figsize=(12, 3.5))
axes[0].hist(x, bins=40)
axes[0].set_title("ep_raw")
axes[1].hist(xw, bins=40)
axes[1].axvline(lo, color="r", ls="--")
axes[1].axvline(hi, color="r", ls="--")
axes[1].set_title("winsor")
axes[2].hist(xz, bins=40)
axes[2].set_title("z-score")
show_figure(fig, "sec3_winsor_z.pdf")

# %%
# Sec3-Cell2
ac = read_table(DATA / "ep_autocorrelation_lags.csv")
display(
    ac.filter(pl.col("stage").is_in(["ep_win_z", "ep_neutral_z"]))
    .pivot(on="stage", index="lag_h", values="mean_autocorr")
    .sort("lag_h")
)
h = 1  # 可改为1—12；先核对月份连续且h小于月份数
months = sorted(panel["ym"].unique().to_list())
month_ids = [int(m[:4]) * 12 + int(m[4:]) for m in months]
assert np.all(np.diff(month_ids) == 1) and 1 <= h < len(months)
wide = panel.pivot(on="ym", index="ts_code", values="ep_neutral_z").fill_nan(None)
lag_values = wide.select(
    [pl.corr(a, b).alias(a) for a, b in zip(months, months[h:])]
).row(0)
A_h = pl.Series(lag_values).fill_nan(None).mean()
reference = ac.filter((pl.col("stage") == "ep_neutral_z") & (pl.col("lag_h") == h))[
    "mean_autocorr"
][0]
assert np.isclose(A_h, reference)
print("现场复算A(h):", h, A_h, "参考表:", reference)

# %%
# Sec4-Cell1
six = read_table(DATA / "example_05_02_six_stocks_ep.csv")
display(six)
for label, rank in [
    ("原始前3", "rank_raw_desc"),
    ("行业去均值前3", "rank_ind_desc"),
    ("行业+市值残差前3", "rank_ind_size_desc"),
]:
    print(label, six.sort(rank)["stock"].head(3).to_list())

# %%
# Sec4-Cell2
ind = read_table(DATA / "ep_industry_distribution_202512.csv")
display(ind.sort("ep_raw_median", descending=True).head(8))
display(ind.sort("ep_raw_median").head(3))
size_corr = read_table(DATA / "ep_size_correlation_monthly.csv")
print("Spearman(EP,lnMV)月均:", size_corr["spearman_before"].mean())
print("Pearson>0月份占比:", (size_corr["pearson_before"] > 0).mean())

# %%
# Sec4-Cell3
ortho = read_table(DATA / "ep_orthogonality_checks.csv")
print("max |X' s| across months:", ortho["max_abs_Xt_score"].max())
display(read_table(DATA / "ep_single_stock_trace_202512.csv"))

# %%
# Sec4-Cell4：与课件一致的sklearn中性化及信号日目标权重
from sklearn.linear_model import LinearRegression

current = panel.filter(pl.col("ym") == "202512").sort("ts_code")
total_mv = current["total_mv"].to_numpy()
z = current["ep_win_z"].to_numpy()
# 明确基准行业及列顺序，去掉一个行业，截距由模型估计。
industries = sorted(current["l1_code"].unique().to_list())
industry_dummies = np.column_stack(
    [(current["l1_code"] == name).to_numpy().astype(float) for name in industries[1:]]
)
X = np.column_stack([np.log(total_mv), industry_dummies])
assert np.isfinite(X).all() and np.isfinite(z).all()
assert np.all(np.ptp(X, axis=0) > 0)
assert np.linalg.matrix_rank(np.column_stack([np.ones(len(z)), X])) == X.shape[1] + 1
model = LinearRegression().fit(X, z)
fitted = model.predict(X)
resid = z - fitted
if np.ptp(resid) == 0 or resid.std(ddof=1) < 1e-15:
    raise ValueError("退化残差无法标准化")
score = (resid - resid.mean()) / resid.std(ddof=1)
assert np.allclose(fitted, current["ep_ols_fit"].to_numpy(), atol=1e-10)
assert np.allclose(resid, current["ep_resid"].to_numpy(), atol=1e-10)
assert np.allclose(score, current["ep_neutral_z"].to_numpy(), atol=1e-10)
assert abs(score.mean()) < 1e-10 and np.max(np.abs(X.T @ score)) < 1e-7
print(
    "代表月中性化复算一致；均值、样本标准差、最大正交误差：",
    score.mean(),
    score.std(ddof=1),
    np.max(np.abs(X.T @ score)),
)
exposure = target_exposure(panel)
display(exposure)
assert abs(exposure["pool_target_weight"].sum() - 1) < 1e-12
assert abs(exposure["Q5_target_weight"].sum() - 1) < 1e-12
print("这是信号日目标权重，尚非受限交易后的实际持仓。得分正交不保证组合权重中性。")

# %%
# Sec5-Cell1
for ym in ["201501", "202512"]:
    d = panel.filter((pl.col("ym") == ym) & pl.col("ret_open_1m").is_finite())
    print(
        ym,
        "N=",
        d.height,
        "Pearson=",
        pearson_ic(d["ep_neutral_z"], d["ret_open_1m"]),
        "Rank=",
        spearman_rank_ic(d["ep_neutral_z"], d["ret_open_1m"]),
    )

# %%
# Sec5-Cell2
ep_normal = np.array([0.02, 0.04, 0.05, 0.07, 0.09, 0.11, 0.14, 0.18])
ret = np.array([-0.032, -0.015, -0.004, 0.008, 0.021, 0.035, 0.062, 0.012])
ep_out = ep_normal.copy()
ep_out[-1] = 1.50
print("8股正常 P/S =", pearson_ic(ep_normal, ret), spearman_rank_ic(ep_normal, ret))
print("8股H异常 P/S =", pearson_ic(ep_out, ret), spearman_rank_ic(ep_out, ret))
A = np.arange(1, 6)
B = np.array([-1, 0, 1, 4, 5])
print("5点 S/P =", spearman_rank_ic(A, B), pearson_ic(A, B))
sixp = read_table(DATA / "example_six_point_outlier.csv")
display(sixp)
print(
    "前5点 P/S =",
    pearson_ic(sixp["factor_val"].head(5), sixp["return_val"].head(5)),
    spearman_rank_ic(sixp["factor_val"].head(5), sixp["return_val"].head(5)),
)
print(
    "6点 P/S =",
    pearson_ic(sixp["factor_val"], sixp["return_val"]),
    spearman_rank_ic(sixp["factor_val"], sixp["return_val"]),
)
print("sum d^2 =", float(sixp["d_rank_sq"].sum()))

# %%
# Sec5-Cell3：当月Pearson IC的双侧检验（对应课件截面检验）
from scipy.stats import t as student_t

rows = []
for ym in ["201501", "202512"]:
    d = panel.filter(
        (pl.col("ym") == ym)
        & pl.col("ret_open_1m").is_finite()
        & pl.col("ep_neutral_z").is_finite()
    )
    n = d.height
    ic = pearson_ic(d["ep_neutral_z"], d["ret_open_1m"])
    if n < 3 or not np.isfinite(ic) or abs(ic) >= 1:
        raise ValueError("经典截面t检验要求N>=3、非退化且|IC|<1")
    t_cs = ic * np.sqrt((n - 2) / (1 - ic**2))
    rows.append(
        {
            "ym": ym,
            "N_stocks": n,
            "pearson_ic": ic,
            "df": n - 2,
            "t_cs": t_cs,
            "p_two_sided": 2 * student_t.sf(abs(t_cs), df=n - 2),
        }
    )
display(pl.DataFrame(rows))
print("这是独立同分布、二元正态假设下的Pearson参考推断；现实股票共同冲击可能破坏假设。")
print("不将该公式直接套给Rank IC；正负方向仍须对照事前研究假说。")

# %%
# Sec5-Cell4
ic_m = read_table(DATA / "ep_ic_monthly_series.csv")
display(ic_m.select("ym", "n", "pearson_ic_neu", "rank_ic_neu").head())
monthly_ic = monthly_rank_ic(panel)
paired = monthly_ic.join(ic_m.select("ym", "rank_ic_neu"), on="ym")
assert np.allclose(
    paired["rank_ic"].to_numpy(), paired["rank_ic_neu"].to_numpy(), atol=1e-12
)
print("132个月逐月复算与参考表一致。Rank IC均值:", monthly_ic["rank_ic"].mean())
print("逐月统计使用实际成对有效样本；截面股票数N与跨期月份数T不同。")

# %%
# Sec6-Cell1
rics = monthly_ic["rank_ic"].to_numpy()
nw = newey_west_t(rics, 4)
mean, sd = float(rics.mean()), float(rics.std(ddof=1))
summary = {
    "mean": mean,
    "sd": sd,
    "ICIR": mean / sd,
    "ann_ICIR": mean / sd * np.sqrt(12),
    "t_iid": nw["t_iid"],
    "t_hac4": nw["t_hac"],
}
print(summary)
# 与课件相同的六期教学序列，不能用粗略标准差替代实际计算。
for label, values in [
    ("A", [0.20, -0.12, 0.22, -0.10, 0.18, -0.08]),
    ("B", [0.62, -0.48, 0.58, -0.42, 0.55, -0.37]),
]:
    values = np.asarray(values)
    print(
        label,
        "均值",
        values.mean(),
        "样本标准差",
        values.std(ddof=1),
        "ICIR",
        values.mean() / values.std(ddof=1),
    )

# %%
# Sec6-Cell2：与课件三张比较表保持同一六阶段口径
neu = read_table(DATA / "ep_neutralization_comparison.csv")
display(
    neu.select("stage", "rank_mean", "rank_std", "rank_icir_unann", "rank_icir_ann")
)
display(
    neu.select(
        "stage", "rank_pos_share", "rank_abs_gt_003_share", "rank_t_iid", "rank_t_hac4"
    )
)
display(
    neu.select(
        "stage",
        "pearson_mean",
        "pearson_std",
        "pearson_icir_unann",
        "pearson_icir_ann",
        "pearson_pos_share",
        "pearson_t_iid",
        "pearson_t_hac4",
    )
)
print("正值比例、绝对IC门槛与统计显著性分别回答不同问题，不互相替代。")

# %%
# Sec6-Cell3
display(read_table(DATA / "ep_ic_summary_by_split.csv").head(12))
cumulative = monthly_ic.with_columns(pl.col("rank_ic").cum_sum().alias("cum_ic"))
fig, ax = plt.subplots()
ax.plot(
    cumulative["ym"].str.strptime(pl.Date, "%Y%m").to_numpy(),
    cumulative["cum_ic"].to_numpy(),
)
ax.set_title("累计Rank IC（ep_neutral_z）")
fig.autofmt_xdate()
show_figure(fig, "sec6_cum_rank_ic.pdf")
print("累计终点:", cumulative["cum_ic"][-1])

# %%
# Sec7-Cell1
dec = read_table(DATA / "ep_ic_decay_summary.csv")
sub = dec.filter(pl.col("sample_mode") == "common_start_121m").sort("horizon_h")
display(
    sub.select(
        "horizon_h", "months_T", "rank_ic_mean", "rank_icir_ann", "pearson_ic_mean"
    )
)
print("共同起始月半衰期:", compute_half_life(sub["rank_ic_mean"], 1))

# 从面板现场复算一个远期单月窗口，再与逐月参考表对齐。
h = 6
recomputed_h = monthly_rank_ic(panel, return_col=f"ret_fwd_h{h}")
ref_h = read_table(DATA / "ep_ic_decay_monthly.csv").filter(pl.col("horizon_h") == h)
check_h = recomputed_h.join(ref_h.select("ym", "rank_ic_neu"), on="ym", how="inner")
assert check_h.height == ref_h.height
assert np.allclose(
    check_h["rank_ic"].to_numpy(),
    check_h["rank_ic_neu"].to_numpy(),
    atol=1e-10,
    equal_nan=True,
)
common_h = recomputed_h.filter(pl.col("ym") <= "202501")
assert common_h.height == 121
reference_h = sub.filter(pl.col("horizon_h") == h)["rank_ic_mean"][0]
assert np.isclose(common_h["rank_ic"].mean(), reference_h)
print(
    "第h个单月窗口复算:",
    h,
    "共同起始月数:",
    common_h.height,
    "均值:",
    common_h["rank_ic"].mean(),
)
# 研究期窗口必须在首个验证信号日之前完成最远端标签。
first_validation = cal.filter(pl.col("split") == "validation")["t_signal"].min()
research_common = cal.filter(
    (pl.col("split") == "research")
    & (pl.col("t_exit_h12").cast(pl.String) < first_validation)
)
assert research_common.height == 48
print(
    "研究期共同窗口：", research_common.height, "月；首个验证信号日：", first_validation
)
display(research_common.select("ym", "t_exit_h12"))

# %%
# Sec7-Cell2
allm = dec.filter(pl.col("sample_mode") == "all_available").sort("horizon_h")
print("全部可用月半衰期:", compute_half_life(allm["rank_ic_mean"], 1))
print("若不固定共同起始月，不同h的时期组成不同，可能改变是否降至一半。")

# %%
# Sec7-Cell3
ind_ic = read_table(DATA / "ep_industry_ic_summary.csv")
display(ind_ic.sort("rank_ic_mean", descending=True).head(8))
print("行业数:", ind_ic.height, "Rank IC>0行业数:", (ind_ic["rank_ic_mean"] > 0).sum())

# %%
# Sec7-Cell4
display(
    read_table(DATA / "ep_pool_summary.csv").select(
        "pool_label",
        "mean_n_stocks",
        "rank_ic_mean",
        "rank_icir_ann",
        "rank_ic_pos_share",
        "rank_ic_t_hac4",
    )
)

# %%
# Sec8-Cell1
demo = assign_quantile(
    panel.filter(pl.col("ym") == "202512").drop_nulls("ep_neutral_z")
)
display(demo.group_by("group").len().sort("group"))
print("按(ep_neutral_z, ts_code)升序后，以floor(kQ/N)+1切成五组。")

# %%
# Sec8-Cell2
eleven = read_table(DATA / "example_ch04_19_eleven_stocks.csv")
display(eleven)
sum_d2, n = eleven["d_rank_sq"].sum(), eleven.height
print("sum d^2:", sum_d2, "Rank IC:", 1 - 6 * sum_d2 / (n * (n * n - 1)))
display(eleven.group_by("group_3").agg(pl.col("ret_pct").mean()).sort("group_3"))

print("11股原教学例按给定边界分3、4、4只；EP真实主案例另用k从0起的floor(kQ/N)+1规则。")

# %%
# Sec8-Cell3：原课件四股教学小例
print("以下为原课件教学小例，不是真实EP组合成绩。")
display(read_table(DATA / "example_ch04_21_ew_vs_vw.csv"))
print("完整期间EW/VW绩效比较暂停：", RESULT_STATUS["portfolio_reason"])

# %%
# Sec8-Cell4：分组后再次检查行业资金权重
display(target_exposure(panel))
print("权重按信号日股票确定，不能因未来收益缺失而删除成员。")

# %%
# Sec9-Cell1：本轮实际计算的停牌暂估记录（截至门禁前）
ev = read_table(DATA / "ep_valuation_events_partial.csv")
display(ev.head(10))
print("每条暂估保留来源日、延续天数、持仓权重与收益贡献；缺少后续兑付/换股链时停止。")
print(RESULT_STATUS["portfolio_reason"])

# %%
# Sec9-Cell2：与课件一致的两股权重漂移教学例
previous = np.array([0.5, 0.5])
returns = np.array([0.2, 0.0])
target = np.array([0.5, 0.5])
drift = previous * (1 + returns) / (1 + previous @ returns)
traded = np.abs(target - drift).sum()
assert np.allclose(drift, [6 / 11, 5 / 11])
print("漂移权重:", drift, "双边成交额占比:", traded, "半和换手:", traded / 2)
print("成员未变仍须再平衡。这是教学例，不是EP组合实证。")

# %%
# Sec9-Cell3：自融资交易费用教学小例——初始净资产1，买入后毛收益10%
rows = []
for bp in [0, 10, 20]:
    c = bp * 1e-4
    stock_value = 1 / (1 + c)
    fee = stock_value * c
    net_return = stock_value * 1.10 - 1
    rows.append(
        {
            "one_way_bp": bp,
            "stock_value": stock_value,
            "fee": fee,
            "net_return": net_return,
        }
    )
    assert np.isclose(stock_value + fee, 1)
display(pl.DataFrame(rows))
print("实际交易先预留费用；不在100%买入后另扣现金造成透支。")

# %%
# Sec9-Cell4：本轮合法回测前缀，之后在无法核实持仓终值处停止
prefix = read_table(DATA / "ep_valid_backtest_prefix.csv")
display(prefix)
print("仅为已完成的前缀月份；不能报告2015–2025全期净值、年化收益或稳健性结论。")

# %%
# Sec10-Cell1：保留方法，不读取已失效的全期绩效表
def portfolio_metrics(net_returns):
    r = np.asarray(net_returns, dtype=float)
    if len(r) < 2 or not np.isfinite(r).all() or np.any(r <= -1):
        raise ValueError("绩效计算需要完整有效收益，且每期收益必须大于-100%")
    nav = np.r_[1.0, np.cumprod(1 + r)]
    return {
        "final_nav": nav[-1],
        "cagr": nav[-1] ** (12 / len(r)) - 1,
        "ann_vol": r.std(ddof=1) * np.sqrt(12),
        "mdd": max_drawdown_from_nav(nav)["mdd"],
    }


print("暂停EP全期绩效：", RESULT_STATUS["portfolio_reason"])
print("下方仅用明确给定的教学收益说明评价方法。")

# %%
# Sec10-Cell2
mdd_ex = read_table(DATA / "example_ch04_26_mdd_5periods.csv")
display(mdd_ex)
print(max_drawdown_from_nav(mdd_ex["nav"].to_numpy()))

# %%
# Sec10-Cell3：相对基准指标的纯计算接口
def relative_metrics(net_returns, benchmark):
    r, b = np.asarray(net_returns, dtype=float), np.asarray(benchmark, dtype=float)
    if r.shape != b.shape or len(r) < 2 or not np.isfinite(r - b).all():
        raise ValueError("组合与基准必须使用相同的完整收益窗口")
    active = r - b
    sd = active.std(ddof=1)
    return {
        "arith_active_ann": 12 * active.mean(),
        "tracking_error_ann": np.sqrt(12) * sd,
        "information_ratio": np.sqrt(12) * active.mean() / sd if sd > 0 else np.nan,
        "active_win_rate": float((active > 0).mean()),
    }


print("当前不计算EP全期主动收益或IR，不能用两个合法前缀月替代全期。")

# %%
# Sec10-Cell4：原课件分组形状教学反例，不是EP实证
shape = pl.DataFrame(
    {
        "group": [1, 2, 3, 4, 5],
        "local_inversion": [0.03, 0.085, 0.062, 0.12, 0.165],
        "inverted_u": [0.04, 0.12, 0.18, 0.14, 0.09],
    }
)
display(shape)
for name in ["local_inversion", "inverted_u"]:
    print(
        name,
        "相邻差:",
        np.diff(shape[name].to_numpy()),
        "层序相关:",
        spearman_rank_ic(shape["group"], shape[name]),
    )

# %%
# Sec10-Cell5：36月给定收益教学例，不是EP实际净值
# 前12月高组每月2%、基准0%；之后两者均每月1%。
high = np.r_[np.full(12, 0.02), np.full(24, 0.01)]
benchmark = np.r_[np.zeros(12), np.full(24, 0.01)]
nav_high, nav_benchmark = np.cumprod(1 + high), np.cumprod(1 + benchmark)
rolling = np.full(36, np.nan)
for end in range(11, 36):
    rolling[end] = np.prod(1 + high[end - 11 : end + 1]) - np.prod(
        1 + benchmark[end - 11 : end + 1]
    )
spread = high - benchmark
ls_research = 0.5 * spread
fig, axes = plt.subplots(2, 2, figsize=(11, 7))
months = np.arange(1, 37)
axes[0, 0].plot(months, nav_high, label="高分组")
axes[0, 0].plot(months, nav_benchmark, label="基准")
axes[0, 0].set_title("教学例：绝对净值")
axes[0, 0].legend()
axes[0, 1].plot(months, nav_high / nav_benchmark)
axes[0, 1].set_title("相对净值比")
axes[1, 0].plot(months, rolling)
axes[1, 0].set_title("滚动12月复合收益之差")
axes[1, 1].bar(months, spread * 100, alpha=0.25)
axes[1, 1].set_ylabel("高组减基准收益差（百分点，左轴）")
ax_right = axes[1, 1].twinx()
ax_right.plot(months, np.cumprod(1 + ls_research), color="C2")
ax_right.set_ylabel("半敞口零费用净值（右轴）")
axes[1, 1].set_title("半敞口零费用净值 / 高组减基准收益差")
show_figure(fig, "sec10_teaching_four_charts.pdf")
assert np.isclose(rolling[23], 0)
print("给定收益教学例指标:", portfolio_metrics(high))

# %%
# Sec11-Cell1：依据当前可核查范围组织结论
display(
    pl.DataFrame(
        {
            "支柱": ["预测力", "组合实现", "适用范围"],
            "证据": [
                "Rank IC / ICIR / HAC t",
                "两月合法前缀与持仓暂估记录",
                "衰减、行业、股票池",
            ],
            "当前边界": [
                "可复算独立统计",
                "全期终值尚未核实，绩效暂停",
                "结论限于已说明的样本与窗口",
            ],
        }
    )
)
print(
    "候选去向：继续收益研究、进入风险研究、观察或定向修改、停止使用。结论由学生依据证据判断。"
)

# %%
# Sec11-Cell2：仅在副本注入三类故障，正式输入不变
bad = pl.concat([panel.head(3), panel.head(1)])
missing_labels = panel.head(1000).with_columns(
    pl.lit(None, dtype=pl.Float64).alias("ret_open_1m")
)
for name, frame in [("重复键", bad), ("标签全缺失", missing_labels)]:
    try:
        validate_panel(frame)
    except ValueError as error:
        print("预期停止：", name, str(error))
    else:
        raise AssertionError("故障未被拦截")
try:
    sample_zscore(np.ones(50))
except ValueError as error:
    print("预期停止：常数特征", str(error))
else:
    raise AssertionError("常数特征未被拦截")

# %%
# Sec11-Cell3：学生自填（保持空白）
brief_line_1 = ""  # 预测力
brief_line_2 = ""  # 组合实现
brief_line_3 = ""  # 边界与限制
print("（提交前请确认三行均已填写）")
print(brief_line_1)
print(brief_line_2)
print(brief_line_3)

# %%
# Sec12-Cell1：人工规则接口；ROE源同键冲突未解决，不输出实证成绩
def manual_score(ep_z, roe_z):
    return 0.5 * np.asarray(ep_z) + 0.5 * np.asarray(roe_z)


print("已知人工规则：score = 0.5 * EP_z + 0.5 * ROE_z")
print("学习模型用历史X、成熟y估计f_theta，随后输出score并重入本讲评价。")
print("当前ROE数据门禁：", RESULT_STATUS["roe_reason"])

# %%
# Sec12-Cell2
print("特征合成系数、模型参数θ、组合资金权重是三个不同对象。")
display(
    cal.filter(pl.col("ym").is_in(["201912", "202212"])).select(
        "ym", "t_signal", "t_enter", "t_exit", "split", "cross_split_boundary"
    )
)
print("训练只用决策时收益已实现的样本，不能只看信号月属于哪一期。")

# %%
# Sec12-Cell3：EP独立统计与模型比较状态分开报告
test_ic = monthly_rank_ic(panel.filter(pl.col("split") == "test"))["rank_ic"].to_numpy()
test_nw = newey_west_t(test_ic, 4)
print("EP原有测试期独立统计（不是四模型共同样本比较成绩）：", test_nw)
iface = pl.DataFrame(
    {
        "model": ["EP", "0.5EP+0.5ROE", "Ridge", "RandomForest"],
        "rank_ic": [None] * 4,
        "icir": [None] * 4,
        "net_return": [None] * 4,
        "status": [
            "待确定四模型共同样本",
            "ROE同键冲突，暂不比较",
            "尚未训练",
            "尚未训练",
        ],
    },
    schema_overrides={
        "rank_ic": pl.Float64,
        "icir": pl.Float64,
        "net_return": pl.Float64,
    },
)
display(iface)
iface.write_csv(OUT / "sec12_eval_interface.csv")
(OUT / "ep_statistics_recomputed.json").write_text(
    json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
)
