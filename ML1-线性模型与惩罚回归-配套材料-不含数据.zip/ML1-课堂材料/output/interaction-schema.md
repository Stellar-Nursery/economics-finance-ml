# ML1交互数据结构与口径（2.0）

`interaction-data.json`由Notebook全量计算生成，schema_version为2.0。相对历史版本，预测输入改为7个中性化信号；行业类别与未见类别字段不再作为预测预处理，股票展示列用EP及六个新信号替代旧规模/流通比例。不得使用历史36列数据回填当前结果。

| 键 | 含义 |
| --- | --- |
| sample_summary | 源行数、特征与标签可用数、7列设计、各阶段样本及标签边界 |
| preprocessing | 初次/最终跨期标准化参数、逐月信号中性化检查；controls_enter_prediction=false |
| feature_names | EP、Mom60、Mom120、Vol20、Vol60、Activity20、Activity60，固定顺序 |
| feature_correlation | 初次训练全样本7×7输入Pearson相关矩阵，不是Rank IC |
| models | EP_score、FrozenMean、EP_OLS、OLS、Ridge、Lasso、ElasticNet的阶段指标与最终参数 |
| tuning_grid / coefficient_paths | 133个唯一状态及7列系数路径；均为初次拟合，不是最终系数 |
| monthly_metrics | 验证、重拟合样本内、教学测试的逐月MSE、IC、Rank IC |
| cross_sections | 四个月份各最多40只展示股票，排名先在全部可预测股票上计算 |
| contribution_examples | 最终四个多变量模型的完整7项贡献，贡献和加截距等于预测 |
| window_demo | 2023-01单月扩展/滚动窗口示范，不是完整回测 |
| validation_checks | 边界、KKT、独立求解、信号及综合预测中性性、Rank IC核验 |
| limitations / provenance | 来源SHA、口径、损失及范围 |

目标函数为 `SSE/(2*n)+lambda*(rho*L1+(1-rho)*L2_squared/2)`，n为当次股票—月份总数，截距不惩罚。验证MSE不含惩罚，按记录等权；λ、ρ控件仅查已计算状态，不能插值虚构测试成绩。Ridge alpha=n*lambda，Lasso/ElasticNet alpha=lambda，ElasticNet l1_ratio=rho。本轮全部模型与scikit-learn作独立数值对照。

中性化使用当月共同可用股票的特征，不使用未来收益；跨期缩放只用训练样本。EP按共同池重算同一流程。缺标签记录仍可预测；评价只用成对有效数据。Rank IC先按月计算，再对可计算月份取平均，不是全部股票—月份一次相关。

所有收益、截距和贡献用小数；MSE单位是小数收益的平方。EP_score的收益误差为null，FrozenMean的IC为null。JSON不用NaN/Infinity，不把未知值填零。`refit_in_sample`不能称为样本外结果，`teaching_test`是历史课堂比较。

输出CSV与JSON字段同义。全量教学测试预测运行后生成于`teaching-test-predictions.parquet`，公开包不预置该全量逐股表；单项信号训练期Rank IC另见`case2-single-signal-rank-ic.csv`。单项信号诊断不替代模型评分的Rank IC，不按单项Rank IC直接赋权。
